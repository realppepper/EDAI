# EDAI · 데이터시트 작업실 v0.4

팀 Drive의 전자부품 데이터시트 또는 직접 올린 PDF·이미지·텍스트로 회로 연결안을 만들고, 근거가 있는 초안을 로컬 SPICE에서 시험하는 프로그램입니다.

## 1. Windows에서 실행

1. ZIP 전체를 새 폴더에 풀고 `program`을 엽니다. 이전 설치는 덮어쓸 필요가 없습니다.
2. Python 3.10 이상이 설치된 PC에서 **START_WITH_NVIDIA.bat**를 두 번 클릭합니다. 처음에는 인터넷으로 PyMuPDF와 Google 인증 라이브러리를 설치합니다. 설치할 때까지 창을 열어 두세요.
3. 검은 창의 **NVIDIA API key:**에 자기 키를 붙여 넣고 Enter를 누릅니다(화면에는 표시되지 않음). 키 입력을 생략하면 로컬 읽기만 시작할 수 있습니다.
4. **http://127.0.0.1:8765**가 열립니다. 이전 EDAI 창이 같은 포트를 쓰면 이전 프로그램을 닫고 다시 실행하세요. 끌 때는 실행 창에서 Ctrl+C를 누릅니다.
5. 실제 회로 시험 단계에서 Windows는 LTspice, Linux는 ngspice가 필요합니다. PDF만 읽거나 연결안을 검토할 때는 없어도 됩니다.

macOS/Linux: `python3 -m venv .venv`, `source .venv/bin/activate`, `python -m pip install -r requirements-ai.txt`, `python start_with_nvidia.py` 순서로 실행합니다.

## 2. 팀원과 처음 3분

- **Google 개발자 설정 없이**: 받은 데이터시트를 **내 파일 → 데이터시트 파일 선택**으로 가져오세요. 동기화한 폴더는 **PC의 팀 폴더 선택**에서 열 수 있습니다.
- **앱에서 Drive 파일을 바로 가져오기**: 아래 4절의 Google 설정 후 **Drive 직접 연결 · 최신 목록**에서 로그인 → 파일 선택. 하위 폴더와 다음 목록도 지원하며, 같은 이름은 날짜·크기·ID 끝자리로 구분합니다. 선택한 파일만 다운로드하며 Drive에는 쓰지 않습니다.
- **다른 데이터시트**: 어느 부품이든 **내 파일**로 PDF·JPG·PNG·UTF-8 TXT를 열거나 **텍스트**에 내용을 붙여 넣으세요. 부품 이름으로 설계 로직이나 결과를 고정하지 않습니다.
- **페이지**: 우선 `1`로 읽은 뒤 표가 있는 쪽을 추가하세요. TLV271.PDF는 원본 17쪽, 3쪽이 핀 배치, 4쪽이 절대최대 등급, 5~6쪽이 전기적 특성입니다. `1, 3-5`같이 지정할 수 있습니다. 24 MiB 이하, PDF 전체 최대 2,500쪽, 한 번의 분석은 선택한 원본 최대 8쪽입니다. 한 쪽씩 호출하며 같은 문서·쪽·방식의 최근 성공 건은 프로그램 메모리에서 재사용합니다. 중단/오류가 나면 완료된 쪽을 검토하고 남은 쪽만 다시 읽을 수 있습니다.
- **읽기와 분석**: ‘선택 페이지 읽기’는 원문 대조까지입니다. 다음에 요구사항을 넣고 **NVIDIA로 설계 항목 분석**을 눌러 수치·단위·종류·측정 조건·쪽번호·인용을 봅니다. 원본에서 확인한 항목에 체크합니다. 읽은 텍스트에 없는 인용은 선택할 수 없습니다. 스캔 자료는 인용이 OCR과 일치해도 원본 이미지와 대조하세요.

복사해서 쓸 수 있는 TLV271용 설계 요청:

> TLV271의 권장 전원 범위와 핀 연결을 먼저 확인해줘. 내가 정한 목표는 5 V 단전원, 비반전 이득 2 V/V야. 입력 바이어스와 출력 범위를 고려해 저항 연결과 한 가지 과도응답 시험을 제안해줘. 전기적 특성표의 전형값은 보장값과 구분하고, 자료에 없는 모델이나 부하 조건은 질문해줘.

## 3. 문서 모델과 설계 모델

| 화면의 선택 | 입력과 목적 | 필요한 것 |
|---|---|---|
| 로컬 읽기 · PyMuPDF | PC에서 PDF 텍스트를 읽고 원본을 미리 봄 | 키 없음. 스캔에는 텍스트 층이 없을 수 있음 |
| NVIDIA API 키 · Nemotron Parse | 페이지를 JPEG로 렌더링한 뒤 NVIDIA Build의 `nvidia/nemotron-parse`에 보내 문서 텍스트를 받음 | NVIDIA API 키와 해당 모델 접근. 호스팅 모델 버전을 3.5로 표시하지 않음 |
| 팀 NIM 서버 · Nemotron 3.5 Parse | 페이지를 PNG로 렌더링해 native `POST /v1/parse`로 보냄 | 실제 3.5 Parse NIM 서비스. 기본 `http://127.0.0.1:8000/v1/parse`. 다른 로컬 포트는 `EDAI_NIM_URL` 환경변수. 실행기가 NIM 서버를 설치하지 않음 |
| NVIDIA 항목 분석·회로 설계·피드백 | 원문 텍스트에서 항목을 찾고, 확인한 근거로 회로안을 만들며, 실제 측정값을 토대로 수정안을 냄 | NVIDIA API 키. 기본 설계 모델 `nvidia/nemotron-3.5-lightning-30b-a3b`. 지원되는 다른 NVIDIA 텍스트 모델은 `EDAI_NVIDIA_DESIGN_MODEL`로 지정 |

호스팅 Parse가 계정에서 제공되지 않거나 호출에 실패하면 오류를 표시합니다. 다른 모델 결과로 자동 대체하지 않습니다. 텍스트가 있는 PDF라면 **로컬 읽기 → NVIDIA로 설계 항목 분석**으로 진행할 수 있습니다. 원문 비교의 숫자 차이는 정확도 지표가 아닙니다. AI 단계는 누를 때만 전송하며 계정 한도가 사용될 수 있습니다. 로컬 NIM 호출에는 클라우드 키를 보내지 않습니다. OpenRouter는 기존 SPICE 탭의 기존 기능용이며 새 작업실에는 필요 없습니다.

## 4. 팀에서 Google Drive 직접 연결을 설정할 때

공유할 Drive 폴더 ID를 실행할 PC의 환경변수 `EDAI_DRIVE_FOLDER_ID`에 설정한 뒤 앱을 시작하세요. 팀에서 한 번 Google Cloud 프로젝트에서 Google Drive API를 켜고 Google Auth Platform을 설정하세요. 외부 앱을 테스트 모드로 쓰면 팀 계정을 테스트 사용자로 등록합니다. **OAuth 클라이언트 ID → 데스크톱 앱**을 만들고 JSON을 내려받아 실행하는 PC의 `program/drive-client.json`에 두거나, `EDAI_GOOGLE_CLIENT`에 그 파일의 경로를 설정하세요. 앱에서 ‘Google 읽기 전용 로그인’을 누르고 권한이 있는 계정을 선택하세요. Google의 읽기 범위는 `drive.readonly`이며 이 앱의 목록·가져오기는 제공한 팀 폴더와 그 하위의 열어 본 항목으로 제한됩니다. 액세스 토큰은 실행 중 메모리에서만 유지됩니다. JSON·키·토큰은 GitHub에 올리지 마세요.

누구나 읽을 수 있는 폴더에만 대안으로 해당 프로젝트의 Drive API 키를 `GOOGLE_DRIVE_API_KEY` 환경변수로 지정할 수 있습니다. NVIDIA 키는 Google 로그인이나 비공개 파일 접근을 대신하지 않습니다. ChatGPT에서 연결한 계정 권한이 내려받은 PC 프로그램에 복사되지는 않습니다. **팀 폴더 공개 설정을 바꿀 필요는 없습니다.**

## 5. 회로를 시험하고 피드백받기

1. 원문과 일치하는 항목을 골라 단위·조건과 목표를 확인합니다. 비교표는 제조사 규격과 사용자가 원하는 목표를 구분합니다.
2. **확인한 근거로 회로 설계**: 기본은 외부 연결·조건·추가 질문입니다. 시뮬레이션이 필요하면 보유한 단일 파일 `.model/.subckt` 본문을 넣거나 교육용 모델을 명시적으로 허용하세요. PDF 핀 그림만으로 제조사 내부 회로나 실제 성능을 복원할 수 없습니다.
3. 형식 검사를 통과한 초안만 **넷리스트 편집기로 가져가기**가 나옵니다. 모델, 전원, 입출력, 목표와 .meas를 확인한 뒤 **SPICE 실행 & 자동 피드백**을 누릅니다. 기본 첫 초안은 1회만 시험합니다. 형식 통과는 성능 검증이 아닙니다.
4. 원하는 후보의 **보기 → 측정 결과를 AI에 보내 회로 수정안 받기**를 누릅니다. 해당 후보의 실제 입력 회로·파라미터·목표와 측정값/누락/실패 상태를 사용합니다. 수정안은 편집기에 가져와 다시 실행해야 합니다. 일부 PLL/디지털/전력 IC는 자료와 유효한 소자 모델이 없어서 연결안에 머물 수 있습니다.
5. 추출과 비교 기록은 **근거 JSON 저장**, 실제 실행의 넷리스트·로그·측정값·사용한 근거는 **전체 결과 ZIP**에 있습니다. 두 결과는 다릅니다.

검증 범위와 실제 팀 문서에 대한 증거는 `docs/V04_CHECKS.md`에 있습니다. 기존 v0.3 시뮬레이터 사용법과 당시 상태는 `docs/LEGACY_v03_KO.md`를 참고하세요.

**공식 문서**: [Google Drive Python 빠른 시작](https://developers.google.com/workspace/drive/api/quickstart/python) · [Drive 폴더 검색](https://developers.google.com/workspace/drive/api/guides/search-files) · [NVIDIA 호스팅 Parse와 NIM 방식](https://docs.nvidia.com/nemo/retriever/latest/extraction/prerequisites-support-matrix/) · [3.5 NIM 요청 형식](https://docs.api.nvidia.com/nim/reference/nvidia-nemotron-3_5-parse-infer) · [설계 모델 API](https://build.nvidia.com/nvidia/nemotron-3.5-lightning-30b-a3b/apireference)
