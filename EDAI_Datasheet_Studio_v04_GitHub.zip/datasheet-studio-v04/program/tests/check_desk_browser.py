"""Optional UI/integration regression. No live AI or Google requests.
Set EDAI_TEST_PDF (the team TLV271.PDF), EDAI_TEST_NGSPICE and optionally
EDAI_TEST_CHROMIUM; run from program/: python tests/check_desk_browser.py .
The simulated circuit is a test fixture, never delivered by the production UI.
"""
import json, os, re, sys, tempfile, threading
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server,nv_service,team_drive
pdf=Path(os.environ['EDAI_TEST_PDF']).read_bytes()
net="""* UI regression only: ideal amplifier, no TLV271 model or power
.param RF=10000
Vin in 0 PULSE(0 0.1 1u 1n 1n 10u 20u)
Eideal out 0 in fb 1e5
Rfeedback out fb {RF}
Rg fb 0 10k
Rload out 0 100k
.tran 5n 5u
.save v(in) v(out)
.meas tran out_v AVG v(out) FROM=2u TO=4u
.end
"""
settings={'title':'UI test, ideal amplifier','parameters':[{'name':'RF','min':8000,'max':12000,'initial':10000,'step':1000}],
          'goals':[{'measure':'out_v','op':'>=','value':.19,'unit':'V'}],'objective':{'measure':'out_v','sense':'max'},
          'method':'single','max_runs':1,'timeout_s':10}
def drive_fetch(path,params,*args):
    if params.get('alt')=='media':return pdf
    return json.dumps({'files':[{'id':'TLV271_fixture','name':'TLV271.PDF','mimeType':team_drive.PDF,'size':str(len(pdf))}]}).encode()
read_pages=[];actual=[]
def nvidia_mock(url,body,mime,cloud):
    assert cloud and url==nv_service.CHAT
    p=json.loads(body)
    if p['model']==nv_service.HOST_MODEL:
        assert p['messages'][0]['content'][0]['image_url']['url'].startswith('data:image/jpeg;base64,')
        read_pages.append(1)
        return {'model':nv_service.HOST_MODEL,'choices':[{'finish_reason':'tool_calls','message':{'tool_calls':[{'function':{'name':'markdown_bbox','arguments':json.dumps([{'text':'Fixture transcription only: Supply Voltage Range 2.7 V to 16 V'}])}}]}}]},'test-parse'
    payload=json.loads(p['messages'][1]['content'])
    if 'pages' in payload:
        r={'summary':'Test analysis; offline fixture','fields':[{'name':'supply','value':'2.7–16','unit':'V','page':1,'quote':'2.7 V to 16 V'}]}
    else:
        if 'actual_run' in payload:actual.append(payload['actual_run'])
        r={'summary':'Test-only educational draft','status':'draft','netlist':net,'settings':settings,'warnings':['Ideal-model fixture']}
    return {'model':nv_service.analyze_model(),'choices':[{'message':{'content':json.dumps(r)},'finish_reason':'stop'}]},'test-language'
with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{'NVIDIA_API_KEY':'offline-fixture','GOOGLE_DRIVE_API_KEY':'offline-fixture'}),patch('team_drive.get_bytes',side_effect=drive_fetch),patch('nv_service.request_json',side_effect=nvidia_mock):
    import shutil
    team_drive.ROOT_ID='fixture_public_root'
    team_drive.catalog={team_drive.ROOT_ID:{'id':team_drive.ROOT_ID,'name':'Fixture','mimeType':team_drive.FOLDER}}
    src=server.ROOT
    for name in ['examples','web']:shutil.copytree(src/name,Path(tmp)/name)
    shutil.copy(src/'team_catalog.json',Path(tmp)/'team_catalog.json')
    server.ROOT=Path(tmp);server.CONFIG={'simulator':'ngspice','simulator_path':os.environ['EDAI_TEST_NGSPICE']}
    http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler);server.PORT=http.server_port;server.ORIGIN=f'http://127.0.0.1:{server.PORT}';threading.Thread(target=http.serve_forever,daemon=True).start()
    try:
        if '--http-only' in sys.argv:
            import io,urllib.request,zipfile,base64,time
            from html.parser import HTMLParser
            class Controls(HTMLParser):
                ids=set()
                def handle_starttag(self,tag,attrs):
                    a=dict(attrs)
                    if 'id' in a:self.ids.add(a['id'])
            def call(route,data=None):
                req=urllib.request.Request(server.ORIGIN+route,headers={'Content-Type':'application/json','X-EDAI-Token':server.TOKEN},data=json.dumps(data).encode() if data is not None else None)
                with urllib.request.urlopen(req,timeout=15) as response:
                    if 'application/json' not in response.headers.get('Content-Type',''):return response.read()
                    return json.load(response)
            html=Controls();html.feed(call('/').decode())
            desk_js=call('/desk.js').decode()
            assert set(re.findall(r"\bel\('([a-z][\w-]*)'\)",desk_js)) <= html.ids
            index=call('/api/desk/catalog')
            assert len({it['id'] for it in index['items']})==index['count']
            def post(stage,**data):return call('/api/desk/'+stage,data)
            local=post('upload',name='TLV271.PDF',base64=base64.b64encode(pdf).decode())
            assert local['pages']==17
            preview=post('preview',doc=local['doc'],page=3)
            assert base64.b64decode(preview['png']).startswith(b'\x89PNG') and 'PINOUT' in preview['text']
            local_page=post('read',doc=local['doc'],page=1,mode='local')
            assert '2.7 V to 16 V' in local_page['text']
            assert 'IMPORTANT NOTICE' in post('read',doc=local['doc'],page=17,mode='local')['text']
            assert not read_pages
            listed=post('drive-list');f=post('drive-file',id=listed['items'][0]['id']);assert f['sha256']==local['sha256']
            parsed=post('read',doc=f['doc'],mode='build',page=1);assert parsed['meta']['request_id']=='test-parse' and len(read_pages)==1
            a=post('analyze',doc=f['doc'],pages=[1],mode='build',goal='Illustrative external feedback only.')
            assert a['fields'][0]['local_match']
            form={'analysis':a['analysis'],'indices':[0],'confirmed':True}
            assert post('design',**form)['status']=='plan'
            d=post('design',**form,illustrative=True);assert not d['verified_by_spice']
            start=call('/api/run',{'netlist':d['netlist'],'settings':d['settings'],'confirmation_id':d['confirmation_id']})
            route='/api/jobs/'+start['id'];end=time.monotonic()+15
            while time.monotonic()<end:
                j=call(route)
                if j['state']!='running':break
                time.sleep(.08)
            assert j['state']=='completed' and j['feasible_count']==1,j['error']
            fb=post('feedback',job_id=j['id'],candidate=0)
            assert fb['status']=='draft' and .199<actual[0]['metrics']['out_v']<.201
            with zipfile.ZipFile(io.BytesIO(call(route+'/download'))) as z:
                pr=json.loads(z.read('document_review.json'))
                assert pr['fields'][0]['page']==1 and pr['sources'][0]['sha256']==local['sha256']
            pasted=post('paste',text='Unrelated part; operating range 1.8 V.');assert post('read',doc=pasted['doc'],page=1,mode='local')['text'].startswith('Unrelated')
            print('PASS: UI controls resolve, local/upload & Drive fixture -> same real 17-page document, pp. 1/3/17; hosted parser + text model fixtures, plan gating, valid test draft -> real ngspice -> selected candidate feedback -> provenance ZIP. Fixture output (V):',actual[0]['metrics']['out_v'])
        else:
            from playwright.sync_api import sync_playwright,expect
            with sync_playwright() as pw:
                args={'args':['--no-sandbox']};exe=os.environ.get('EDAI_TEST_CHROMIUM')
                if exe:args['executable_path']=exe
                b=pw.chromium.launch(**args);p=b.new_page(viewport={'width':1220,'height':850});p.set_default_timeout(10000);fail=[]
                p.on('pageerror',lambda e:fail.append(str(e)));p.goto(server.ORIGIN);expect(p.locator('#nv-status')).to_contain_text('키 설정됨')
                p.locator('#src-file').click()
                p.locator('#desk-file').set_input_files({'name':'TLV271.PDF','mimeType':'application/pdf','buffer':pdf})
                expect(p.locator('#doc-badge')).to_contain_text('17쪽')
                p.locator('#preview-no').fill('3');p.locator('#preview-button').click()
                expect(p.locator('#preview-title')).to_contain_text('원본 3쪽')
                expect(p.locator('#preview-body img')).to_be_visible();p.locator('#preview-close').click()
                p.locator('#reader-mode').select_option('local');p.locator('#ds-range').fill('1, 17');p.locator('#ds-read').click()
                expect(p.locator('#ds-pages')).to_contain_text('2.7 V to 16 V');expect(p.locator('#ds-pages')).to_contain_text('IMPORTANT NOTICE')
                assert not read_pages
                p.locator('#src-drive').click();p.locator('#drive-list').click()
                p.locator('#drive-items button').first.click();expect(p.locator('#doc-badge')).to_contain_text('Google Drive')
                p.locator('#ds-read').click();expect(p.locator('#ds-pages')).to_contain_text('Fixture transcription only');assert len(read_pages)==1
                p.locator('#ds-goal').fill('테스트: 비반전 피드백의 교육용 이득 확인.');p.locator('#ds-analyze').click()
                p.locator('#ds-fields input').check();p.locator('#ds-educational').check();p.locator('#ds-consent').check();p.locator('#ds-design').click()
                expect(p.locator('#draft-card')).to_contain_text('Test-only educational draft');p.locator('#draft-apply').click();expect(p.locator('#netlist')).to_have_value(net)
                p.locator('#run').click();expect(p.locator('#run-status')).to_contain_text('실행 완료',timeout=20000)
                expect(p.locator('#feasible')).to_have_text('1');p.locator('#refine').click();expect(p.locator('#draft-title')).to_contain_text('후보 #0 피드백')
                assert actual and .199<actual[0]['metrics']['out_v']<.201
                p.locator('#src-text').click();p.locator('#ds-paste').fill('Other device. VDD=1.8 V.');p.locator('#paste-open').click()
                expect(p.locator('#doc-badge')).to_contain_text('붙여넣기');expect(p.locator('#analysis-card')).to_be_hidden();expect(p.locator('#reader-mode')).to_have_value('local')
                p.set_viewport_size({'width':390,'height':840});assert p.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
                if os.environ.get('EDAI_TEST_UI_IMAGE'):
                    p.set_viewport_size({'width':1360,'height':900});p.reload();expect(p.locator('#nv-status')).to_contain_text('키 설정됨');p.screenshot(path=os.environ['EDAI_TEST_UI_IMAGE'])
                assert not fail,fail
                print('PASS: real 17-page team PDF, pp. 1/3/17; local, Drive fixture, hosted parser fixture, evidence, design -> real ngspice -> selected candidate feedback; mobile width OK. Fixture output (V):',actual[0]['metrics']['out_v'])
                b.close()
    finally:http.shutdown();http.server_close();server.ROOT=src
