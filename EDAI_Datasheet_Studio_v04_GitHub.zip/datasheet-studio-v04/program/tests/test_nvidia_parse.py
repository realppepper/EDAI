import base64, json, unittest
from unittest.mock import patch
import nvidia_parse as nv
from review import extract

class Response:
    headers={'x-request-id':'test-request'}
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,*args):return json.dumps({'content':'<x_0.1>Supply 3.3 V<class_Text>','finish_reason':'stop','usage':{'output_tokens':9}}).encode()
class Opener:
    def open(self,request,timeout):
        self.request=request
        return Response()
class NvidiaTests(unittest.TestCase):
    def test_native_multipart_and_metadata(self):
        opener=Opener()
        with patch('urllib.request.build_opener',return_value=opener):
            text,meta=nv.call_page(b'png-bytes','https://integrate.api.nvidia.com/v1/parse','TEST_ONLY','native')
        self.assertIn(b'name="document"',opener.request.data)
        self.assertIn(b'png-bytes',opener.request.data)
        self.assertEqual(meta['request_id'],'test-request')
        self.assertNotIn('TEST_ONLY',json.dumps(meta))
    def test_reject_key_exfiltration(self):
        for url in ['https://example.org/v1/parse','http://integrate.api.nvidia.com/v1/parse','https://api.nvidia.com.attacker.org/v1/parse','https://user:pass@api.nvidia.com/v1/parse']:
            with self.assertRaises(ValueError):nv.validate_endpoint(url)
    def test_nvidia_only_does_not_need_openrouter(self):
        result={'pages':[],'sources':[],'fields':[],'mode':'nvidia','comparisons':[]}
        with patch('nvidia_parse.extract_nvidia',return_value=result):
            self.assertIs(extract({'extractor':'nvidia','use_ai':False,'files':[]},{}),result)
    def test_page_comparison(self):
        import pymupdf, os
        doc=pymupdf.open();page=doc.new_page();page.insert_text((40,40),'Supply 3.3 V');raw=doc.tobytes();doc.close()
        with patch.dict(os.environ,{'NVIDIA_PARSE_ENDPOINT':'http://127.0.0.1:8000/v1/parse'}),patch('nvidia_parse.call_page',return_value=('Supply 3.3 V',{'latency_s':0})):
            result=nv.extract_nvidia([{'name':'test.pdf','base64':base64.b64encode(raw).decode()}])
        self.assertEqual(result['comparisons'][0]['text_similarity'],1)
        self.assertEqual(result['pages'][0]['page'],1)
        self.assertEqual(result['fields'],[])
