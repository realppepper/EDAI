import base64
import copy
import io
import json
import os
from pathlib import Path
import re
import unittest
from unittest.mock import patch

import datasheet_desk as desk
import nv_service as nv
import team_drive as drive
from engine import parse_measurements

class Documents(unittest.TestCase):
    def setUp(self):
        import pymupdf
        with pymupdf.open() as pdf:
            for i in range(1,16):pdf.new_page().insert_text((30,40),f'Fixture page {i}. Supply range: 3 V to 5 V.')
            self.obj=desk.register('any-part.pdf',pdf.tobytes())
        self.args={'doc':self.obj['doc'],'mode':'local','page':15}

    def test_selected_page_original_index_hash_and_cache(self):
        got=desk.extraction(self.args)
        self.assertEqual(got['page'],15);self.assertIn('Fixture page 15',got['text'])
        self.assertEqual(self.obj['pages'],15)
        with patch('nv_service.parse_page',return_value=('OCR copy 15 V',{'mode':'native','model':nv.NIM_MODEL})) as call:
            remote=dict(self.args,mode='native');first=desk.extraction(remote);second=desk.extraction(remote)
            self.assertEqual(first,second);self.assertEqual(call.call_count,1)
            self.assertIn('5',first['local_only']);self.assertEqual(call.call_args.args[2],'image/png')
        with self.assertRaises(ValueError):desk.extraction(dict(self.args,page=16))

    def test_citation_gate_and_no_invented_model(self):
        desk.extraction(self.args)
        fields=[{'name':'supply','value':'3 to 5','quote':'Supply range: 3 V to 5 V.', 'page':15},
                {'name':'fabrication','value':'99','quote':'99 V max', 'page':15}]
        with patch('nv_service.reason',return_value=({'fields':fields,'summary':'read'}, {'model':'fixture'})):
            a=desk.analyze({'doc':self.obj['doc'],'pages':[15],'mode':'local','goal':'Use at 3.3 V.'})
        self.assertEqual([f['reader_match'] for f in a['fields']],[True,False])
        data={'analysis':a['analysis'],'indices':[1],'confirmed':True}
        with self.assertRaisesRegex(ValueError,'인용'):desk.confirmed(data)
        snap=desk.confirmed(dict(data,indices=[0]))
        with patch('nv_service.reason',return_value=({'status':'draft','netlist':'not a circuit','connections':['connection to check']},{'model':'fixture'})):
            result=desk.draft(snap,'ngspice')
        self.assertEqual(result['status'],'plan');self.assertNotIn('netlist',result)

    def test_hosted_parse_contract_and_native_independence(self):
        reply={'choices':[{'finish_reason':'tool_calls','message':{'content':None,'tool_calls':[{'function':{'name':'markdown_bbox','arguments':json.dumps([{'bbox':[0,0,.3,.1],'type':'Text','text':'ABC 3.3 V'}])}}]}}]}
        with patch('nv_service.cloud_json',return_value=(reply,'request')) as mock:
            text,meta=nv.parse_page(b'example','build','image/jpeg')
        sent=mock.call_args.args[0];self.assertEqual(sent['model'],'nvidia/nemotron-parse')
        self.assertEqual([c['type'] for c in sent['messages'][0]['content']],['image_url'])
        self.assertEqual(text,'ABC 3.3 V');self.assertEqual(meta['request_id'],'request')
        with patch('nv_service.request_json',return_value=({'content':'<x_0.3>3.3 V<class_Text>','finish_reason':'stop'},'')) as native:
            text,meta=nv.parse_page(b'example','native','image/png')
        self.assertEqual(text,'3.3 V');self.assertFalse(native.call_args.args[3])
        self.assertIn(b'name="document"',native.call_args.args[1]);self.assertNotIn(b'"model"',native.call_args.args[1])

    def test_failed_reader_is_not_a_cached_success(self):
        with patch('nv_service.parse_page',side_effect=ValueError('HTTP 401')):
            with self.assertRaisesRegex(ValueError,'401'):desk.extraction(dict(self.args,mode='build'))
        with self.assertRaisesRegex(ValueError,'읽기'):desk.analyze({'doc':self.obj['doc'],'pages':[15],'mode':'build','goal':'Interpret range'})
        with self.assertRaises(ValueError):desk.register('fake.pdf',b'<html>Login</html>')

class TeamFolder(unittest.TestCase):
    @patch('team_drive.ROOT_ID', 'fixture_public_root')
    @patch('team_drive.catalog', {'fixture_public_root': {
        'id': 'fixture_public_root', 'mimeType': drive.FOLDER}})
    def test_listing_membership_and_pagination(self):
        response={'files':[{'name':'same.pdf','id':'team_pdf_1','mimeType':drive.PDF,'modifiedTime':'2026-11-11','size':'100'},
                           {'name':'same.pdf','id':'team_pdf_2','mimeType':drive.PDF,'size':'101'}],'nextPageToken':'more'}
        with patch('team_drive.get_bytes',return_value=json.dumps(response).encode()) as m:
            r=drive.listing({'folder':drive.ROOT_ID});self.assertIn(drive.ROOT_ID,m.call_args.args[1]['q'])
            self.assertEqual(r['next'],'more');self.assertEqual(len({x['id'] for x in r['items']}),2)
            drive.listing({'next':'more'});self.assertEqual(m.call_args.args[1]['pageToken'],'more')
        with self.assertRaises(ValueError):drive.download('not_listed')
        with patch('team_drive.get_bytes',return_value=b'%PDF-test'):
            self.assertEqual(drive.download('team_pdf_1'),('same.pdf',b'%PDF-test'))

class Feedback(unittest.TestCase):
    def test_ltspice_when_vs_find_and_max(self):
        log='cross: V(out)=0.098 AT 1.00010459867e-06\npeak: MAX(V(out))=3.5 AT 5e-6\nval: V(out)=0.4 AT 9e-6'
        net='* test\n.meas tran cross WHEN V(out)=0.098 CROSS=1\n.meas tran peak MAX V(out)\n.meas tran val FIND V(out) AT 9u\n.end'
        self.assertEqual(parse_measurements(log,['cross','peak','val'],net),{'cross':1.00010459867e-6,'peak':3.5,'val':.4})
    def test_selected_candidate_only_and_no_local_path(self):
        base={'iteration':0,'parameters':{'R':1},'metrics':{'gain':1},'checks':[],'log_tail':'local private path'}
        job={'state':'completed','netlist':'* t\n.param R=1\n.end','settings':{},'runs':[base,dict(base,iteration=1,metrics={'gain':2},parameters={'R':5})]}
        out=desk.feedback_for(job,1);self.assertEqual(out['metrics'],{'gain':2});self.assertIn('.param R=5',out['netlist']);self.assertNotIn('private path',json.dumps(out))
        with self.assertRaises(ValueError):desk.feedback_for(job,3)

if __name__=='__main__':unittest.main()
