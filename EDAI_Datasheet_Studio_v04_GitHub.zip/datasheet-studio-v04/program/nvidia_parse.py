"""Page-image NVIDIA adapter. Credentials remain in process environment."""
import base64, difflib, json, os, re, time, urllib.request, urllib.error, urllib.parse, uuid
from ai_input import prepare_sources

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('NVIDIA 요청의 리다이렉트는 허용하지 않습니다.')

def validate_endpoint(url):
    u=urllib.parse.urlsplit(url)
    local=u.hostname in ('localhost','127.0.0.1','::1')
    trusted=u.hostname and (u.hostname.endswith('.api.nvidia.com') or u.hostname=='api.nvidia.com')
    if u.username or u.password or u.query or u.fragment or not ((local and u.scheme in ('http','https')) or (trusted and u.scheme=='https')):
        raise ValueError('NVIDIA 공식 api.nvidia.com HTTPS 주소 또는 로컬 NIM 주소를 입력하세요.')
    return url

def call_page(png, endpoint, key, mode):
    validate_endpoint(endpoint)
    headers={'Accept':'application/json'}
    if key: headers['Authorization']='Bearer '+key
    if mode=='native':
        boundary='edai'+uuid.uuid4().hex
        body=('--'+boundary+'\r\nContent-Disposition: form-data; name="document"; filename="page.png"\r\nContent-Type: image/png\r\n\r\n').encode()+png+('\r\n--'+boundary+'--\r\n').encode()
        headers['Content-Type']='multipart/form-data; boundary='+boundary
    elif mode=='chat':
        body=json.dumps({'model':'nvidia/nemotron-3.5-parse','messages':[{'role':'user','content':[{'type':'text','text':'</s><s><predict_bbox><predict_classes><output_markdown><predict_text_in_pic>'},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(png).decode()}}]}],'max_tokens':9000,'stream':False}).encode()
        headers['Content-Type']='application/json'
    else: raise ValueError('지원하는 API 형식은 native 또는 chat입니다.')
    start=time.monotonic()
    try:
        with urllib.request.build_opener(NoRedirect).open(urllib.request.Request(endpoint,data=body,headers=headers),timeout=120) as r:
            raw=r.read(4_000_001)
            if len(raw)>4_000_000:raise ValueError('NVIDIA 응답 크기 제한 초과')
            data=json.loads(raw)
            request_id=r.headers.get('x-request-id','')
    except urllib.error.HTTPError as e:
        hints={401:'NVIDIA 키 인증 실패',403:'모델 사용 권한 확인 필요',404:'API 주소 또는 모델 지원 여부 확인 필요',429:'호출 한도 초과'}
        raise ValueError('NVIDIA HTTP '+str(e.code)+': '+hints.get(e.code,'API 처리 실패')) from None
    except (urllib.error.URLError,TimeoutError):raise ValueError('NVIDIA 연결 실패 또는 시간 초과. 자동 재호출하지 않습니다.') from None
    except (json.JSONDecodeError,UnicodeError):raise ValueError('NVIDIA JSON 응답 형식 오류') from None
    try:
        choice=data['choices'][0] if mode=='chat' else data
        content=choice['message']['content'] if mode=='chat' else data['content']
        if not isinstance(content,str) or not content.strip():raise ValueError('NVIDIA 추출 내용이 비어 있습니다.')
        if choice.get('finish_reason') in ('length','max_tokens'):raise ValueError('NVIDIA 응답이 길이 제한으로 잘렸습니다. 페이지를 분할해 주세요.')
    except (KeyError,IndexError,TypeError):raise ValueError('NVIDIA 응답에서 추출 내용을 찾지 못했습니다. API 형식을 확인하세요.') from None
    return content,{'latency_s':round(time.monotonic()-start,3),'request_id':request_id,'model':data.get('model',''),'requested_model':'nvidia/nemotron-3.5-parse','usage':data.get('usage',{}),'finish_reason':choice.get('finish_reason')}

def extract_nvidia(files):
    endpoint=os.environ.get('NVIDIA_PARSE_ENDPOINT','').strip()
    if not endpoint:raise ValueError('START_WITH_NVIDIA.bat에서 NVIDIA API 주소를 먼저 설정하세요.')
    validate_endpoint(endpoint)
    key=os.environ.get('NVIDIA_API_KEY','')
    if urllib.parse.urlsplit(endpoint).hostname not in ('localhost','127.0.0.1','::1') and not key:raise ValueError('NVIDIA_API_KEY가 필요합니다. OpenRouter 키와 다릅니다.')
    # Validate file count, sizes, PDF page limits and source hashes before transmission.
    _,sources=prepare_sources(files)
    if any(s['kind']!='pdf' for s in sources):raise ValueError('NVIDIA 비교 추출은 PDF만 선택해 주세요.')
    import pymupdf
    pages=[];comparisons=[]
    for f in files:
        with pymupdf.open(stream=base64.b64decode(f['base64']),filetype='pdf') as doc:
            for i,page in enumerate(doc):
                local=page.get_text()
                scale=min(2,2048/max(page.rect.width,page.rect.height))
                png=page.get_pixmap(matrix=pymupdf.Matrix(scale,scale),alpha=False).tobytes('png')
                content,meta=call_page(png,endpoint,key,os.environ.get('NVIDIA_PARSE_MODE','native'))
                clean=re.sub(r'<(?:x_[^>]*|y_[^>]*|class_[^>]*)>','',content)
                norm=lambda s:re.sub(r'\s+','',s)
                nums=lambda s:set(re.findall(r'[-+]?\d+(?:\.\d+)?',s))
                a,b=nums(local),nums(clean)
                pages.append({'source':f['name'],'page':i+1,'text':clean})
                comparisons.append({'source':f['name'],'page':i+1,'local_text':local,'nvidia_text':clean,'raw_content':content,'local_chars':len(local),'nvidia_chars':len(clean),'text_similarity':round(difflib.SequenceMatcher(None,norm(local),norm(clean),autojunk=False).ratio(),4),'local_only_numbers':sorted(a-b),'nvidia_only_numbers':sorted(b-a),'metadata':meta})
    return {'sources':sources,'pages':pages,'fields':[],'comparisons':comparisons,'mode':'nvidia','model':'nvidia/nemotron-3.5-parse','verified_by_spice':False,'warnings':['문자 유사도와 숫자 차이는 정확도 점수가 아닙니다. 원본 PDF와 값·단위·조건을 직접 대조하세요.','NVIDIA 추출은 문서 파싱이며 회로 시뮬레이션이나 성능 검증이 아닙니다.']}
