'use strict';
(() => {
  const el=id=>document.getElementById(id), node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  const req=(action,data={})=>api('/api/desk/'+action,data);
  const ext=/\.(pdf|png|jpe?g|txt)$/i, MIB=1024*1024;
  let info=null, rows=new Map(), analysis=null, draft=null, cfg=null, src='drive', stopped=false, busy=false;
  let driveRows=[],dirFiles=null,path=[],next='',incomplete=false,indexDate='';
  function msg(t='',bad=false){const n=el('desk-message');n.hidden=!t;n.classList.toggle('problem',bad);n.textContent=t;}
  function view(desk){el('desk-view').hidden=!desk;el('bench-view').hidden=desk;el('show-desk').setAttribute('aria-pressed',desk);el('show-bench').setAttribute('aria-pressed',!desk);el('error').hidden=desk||!el('error').textContent;if(!desk&&status&&!status.ready){el('setup').open=true;error(status.error);}window.scrollTo({top:0,behavior:'instant'});}
  el('show-desk').onclick=()=>view(true);el('show-bench').onclick=()=>view(false);
  el('extract-nvidia').onclick=()=>view(true);
  function source(which){src=which;for(const s of ['drive','file','text']){el('src-'+s).setAttribute('aria-pressed',s===which);el(s+'-pane').hidden=s!==which;}msg();}
  for(const s of ['drive','file','text'])el('src-'+s).onclick=()=>source(s);
  async function task(fn){if(busy)return;busy=true;const saved=Array.from(el('desk-view').querySelectorAll('button,input,select,textarea')).filter(n=>n.id!=='ds-stop'&&n.id!=='preview-close').map(n=>[n,n.disabled]);saved.forEach(([n])=>n.disabled=true);
    try{await fn();}catch(e){msg(e.message||'요청을 완료하지 못했습니다.',true);el('desk-message').scrollIntoView({block:'nearest'});}
    finally{saved.forEach(([n,b])=>n.disabled=b);busy=false;sync();}}
  function clearDesign(){draft=null;el('draft-card').hidden=true;el('ds-consent').checked=false;}
  function clearAnalysis(){analysis=null;el('analysis-card').hidden=true;clearDesign();}
  function pages(){if(!info)throw Error('자료를 먼저 여세요.');const s=el('ds-range').value.trim();const nums=new Set();
    for(const token of s.split(',')){const m=token.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
      if(!m)throw Error('쪽번호 예: 1, 3-5');const a=Number(m[1]),b=Number(m[2]||m[1]);
      if(a<1||b<a||b>info.pages)throw Error('원본 1~'+info.pages+'쪽 범위 안에서 선택하세요.');
      if(b-a>=8)throw Error('한 번에 8쪽까지 읽을 수 있습니다. 범위를 나눠 선택하세요.');
      for(let i=a;i<=b;i++)nums.add(i);if(nums.size>8)throw Error('한 번에 최대 8쪽입니다.');}
    return [...nums].sort((a,b)=>a-b);}
  function sync(){el('read-controls').disabled=!info;el('read-empty').hidden=Boolean(info);
    el('reader-help').textContent=({build:'선택한 쪽 이미지만 NVIDIA Build로 보냅니다. 호스팅 모델 ID: nvidia/nemotron-parse.',native:'페이지 이미지를 PC의 /v1/parse에 보냅니다. 3.5 Parse NIM이 별도로 실행 중이어야 합니다.',local:'외부 전송 없이 글자를 읽습니다. 스캔 이미지의 글자는 NVIDIA 읽기를 선택하세요.'})[el('reader-mode').value];
    if(info?.kind==='text'){el('reader-mode').value='local';el('reader-mode').disabled=true;el('reader-help').textContent='텍스트는 OCR 없이 바로 읽습니다. 항목 분석 단계에서만 NVIDIA로 보냅니다.';}else el('reader-mode').disabled=false;
    el('drive-more').hidden=!next||!!dirFiles;el('drive-up').hidden=path.length<=1||!!dirFiles;
    el('ds-analyze').disabled=!rows.size||!window.dsAiReady;el('ds-analyze').title=window.dsAiReady?'':'START_WITH_NVIDIA.bat에서 키를 입력하세요.';
    const picks=el('ds-fields').querySelectorAll('input:checked').length;
    el('ds-design').disabled=!analysis||!picks||!el('ds-consent').checked;
    el('draft-apply').hidden=draft?.status!=='draft';}
  function openDoc(r){info=r;rows.clear();clearAnalysis();el('ds-model-text').value='';el('ds-educational').checked=false;el('ds-goal').value='';
    el('evidence-card').hidden=true;el('preview-card').hidden=true;el('ds-range').value='1';el('preview-no').value='1';el('preview-no').max=r.pages;
    if(r.kind==='text')el('reader-mode').value='local';else el('reader-mode').value=window.dsAiReady?'build':'local';
    el('ds-range-hint').textContent='전체 '+r.pages+'쪽 · 원본 기준 · 한 번에 8쪽까지';
    const b=el('doc-badge');b.replaceChildren(node('b',r.name),node('small',r.origin+' · '+r.pages+'쪽 · '+(r.bytes/1024).toFixed(0)+' KiB'));b.hidden=false;
    msg(r.name+'을 열었습니다. 필요한 쪽을 선택하세요.');}
  async function fileOpen(f,directory=false){if(!f||!ext.test(f.name))throw Error('PDF·PNG·JPG·TXT 중 하나를 선택하세요.');if(f.size>24*MIB)throw Error('파일 한 개는 24 MiB 이하여야 합니다.');openDoc(await req('upload',{...await encodeFile(f),directory}));}
  el('desk-file').onchange=e=>{const f=e.target.files[0];if(f)task(()=>fileOpen(f));e.target.value='';};
  el('paste-open').onclick=()=>task(async()=>openDoc(await req('paste',{text:el('ds-paste').value})));
  function catalog(){let filter=el('drive-filter').value.toLocaleLowerCase();const root=el('drive-items');root.replaceChildren();
    let source=dirFiles?dirFiles.map((f,i)=>({name:f.name,label:f.webkitRelativePath,size:f.size,fi:i})):driveRows;
    const hits=source.filter(x=>(x.label||x.name).toLocaleLowerCase().includes(filter));
    if(!hits.length)root.append(node('p',incomplete?'일부 목록만 반환되었습니다. Drive에서 확인하거나 다시 불러오세요.':next?'현재까지 불러온 목록에 없습니다. 다음 목록을 확인하세요.':'표시할 PDF 또는 폴더가 없습니다.','note'));
    for(const x of hits){const b=node(x.link?'a':'button',x.folder?'▸ '+x.name:x.name);
      if(x.link){const u=new URL(x.link);if(u.origin!=='https://drive.google.com')continue;b.href=u.href;b.target='_blank';b.rel='noopener noreferrer';b.className='catalog-link';}else b.type='button';
      b.append(node('small',dirFiles?x.label:x.folder?'하위 폴더':[(x.size/MIB).toFixed(2)+' MiB',x.modified,'ID …'+x.id.slice(-7)+(x.link?' · Drive에서 열기 ↗':'')].filter(Boolean).join(' · ')));
      b.disabled=!x.folder&&(x.downloadable===false||x.size>24*MIB);
      if(!x.link)b.onclick=()=>task(async()=>{if(dirFiles)await fileOpen(dirFiles[x.fi],true);else if(x.folder){await loadDrive(x.id,x.name);}else{msg('Google Drive에서 선택한 PDF를 읽고 있습니다…');openDoc(await req('drive-file',{id:x.id}));}});
      root.append(b);}
    el('drive-picker').hidden=false;el('crumb').textContent=dirFiles?'내 PC의 팀 폴더':indexDate?'팀 PDF '+driveRows.length+'개 · '+indexDate+' 확인 목록':path.map(p=>p.name).join(' / ');}
  async function loadDrive(id,name,more=false,back=false){const r=await req('drive-list',{folder:id,next:more?next:''});dirFiles=null;indexDate='';
    if(!more){driveRows=[];if(back)path.pop();else if(id===cfg.drive.root)path=[{id,name}];else path.push({id,name});el('drive-filter').value='';}
    driveRows.push(...r.items);next=r.next;incomplete=r.incomplete;catalog();msg('PDF 또는 하위 폴더를 선택하세요.'+(incomplete?' · Drive가 일부 목록만 반환했습니다.':''));}
  el('team-index').onclick=()=>task(async()=>{const data=await api('/api/desk/catalog');dirFiles=null;path=[];next='';incomplete=false;indexDate=data.checked;
    driveRows=data.items.map(x=>({id:x.id,name:x.name,size:x.size,modified:x.date,link:x.url}));el('drive-filter').value='';catalog();
    msg('확인한 팀 파일 목록입니다. 파일명을 눌러 원본을 열고, 내려받은 PDF는 ‘내 파일’에 넣으세요. 직접 연결하면 앱에서 바로 가져올 수 있습니다.');});
  el('drive-filter').oninput=catalog;
  el('folder-input').onchange=e=>{const files=Array.from(e.target.files).filter(f=>/\.pdf$/i.test(f.name));e.target.value='';if(!files.length){msg('폴더 안에서 PDF를 찾지 못했습니다.',true);return;}
    dirFiles=files;next='';incomplete=false;el('drive-filter').value='';catalog();sync();msg(files.length+'개 PDF를 찾았습니다. 선택한 파일만 프로그램에서 엽니다.');};
  el('drive-list').onclick=()=>task(async()=>{if(!cfg)throw Error('페이지를 새로고침하세요.');if(!cfg.drive.root){el('drive-help').open=true;throw Error('EDAI_DRIVE_FOLDER_ID를 설정하거나 내 파일 또는 PC 폴더를 사용하세요.');}if(!cfg.drive.connected){el('drive-help').open=true;if(cfg.drive.can_login){msg('Google에서 팀 계정으로 로그인하세요.');cfg.drive=await req('drive-login');}else throw Error('Drive 직접 연결 설정이 없습니다. 팀 폴더에서 내려받아 ‘내 파일’로 열거나 ‘PC의 팀 폴더 선택’을 사용하세요.');}await loadDrive(cfg.drive.root,'공유 폴더');});
  el('drive-login').onclick=()=>task(async()=>{msg('Google 로그인 창에서 팀 계정을 선택하세요.');cfg.drive=await req('drive-login');await loadDrive(cfg.drive.root,'공유 폴더');});
  el('drive-more').onclick=()=>task(()=>loadDrive(path.at(-1).id,path.at(-1).name,true));
  el('drive-up').onclick=()=>task(()=>loadDrive(path.at(-2).id,path.at(-2).name,false,true));
  el('preview-button').onclick=()=>task(async()=>{const n=Number(el('preview-no').value);const p=await req('preview',{doc:info.doc,page:n});
    el('preview-card').hidden=false;el('preview-title').textContent=info.name+' · 원본 '+n+'쪽';const box=el('preview-body');box.replaceChildren();
    if(p.png){const img=node('img');img.src='data:image/png;base64,'+p.png;img.alt=info.name+' 원본 '+n+'쪽';box.append(img);}else box.append(node('pre',p.text));
    el('preview-card').scrollIntoView({block:'start'});});
  el('preview-close').onclick=()=>{el('preview-card').hidden=true;};
  function resetRead(){rows.clear();clearAnalysis();el('evidence-card').hidden=true;msg();sync();}
  el('reader-mode').onchange=resetRead;el('ds-range').oninput=resetRead;
  function renderRows(){el('evidence-card').hidden=!rows.size;const box=el('ds-pages');box.replaceChildren();
    for(const r of rows.values()){const d=node('details',null,'ds-page');d.open=rows.size===1;
      d.append(node('summary','원본 '+r.page+'쪽 · '+r.meta.model));const g=node('div',null,'dscompare');
      const texts=r.meta.mode==='local'?[['로컬 원문',r.local]]:[['로컬 원문 · PyMuPDF',r.local],['NVIDIA 추출',r.text]];
      for(const [name,t] of texts){const v=node('div');v.append(node('b',name),node('pre',t||'(텍스트 층 없음)'));g.append(v);}d.append(g);
      if(r.meta.mode!=='local')d.append(node('p','로컬에만 있는 숫자: '+(r.local_only.join(', ')||'없음')+' / NVIDIA에만 있는 숫자: '+(r.reader_only.join(', ')||'없음')+' · 차이는 오류율이 아닙니다.','note'));
      box.append(d);}
  }
  el('ds-stop').onclick=()=>{stopped=true;msg('현재 쪽이 끝나면 멈춥니다. 이미 읽은 결과는 남습니다.');};
  el('ds-read').onclick=()=>task(async()=>{const ns=pages(),mode=el('reader-mode').value;
    if(mode==='build'&&!cfg.nvidia)throw Error('NVIDIA 키를 실행 창에서 설정하거나 ‘로컬 읽기’를 선택하세요.');
    stopped=false;el('ds-stop').hidden=false;
    try{for(const n of ns){if(stopped)break;if(rows.has(n))continue;msg(info.name+' · 원본 '+n+'쪽 읽는 중 ('+(rows.size+1)+'/'+ns.length+')…');
      const row=await req('read',{doc:info.doc,page:n,mode});rows.set(n,row);renderRows();}
      msg('선택한 '+ns.length+'쪽 중 '+rows.size+'쪽 읽음.'+(rows.size<ns.length?' 다시 누르면 남은 쪽을 이어 읽습니다.':' 이제 목표를 입력하세요.'));}
    finally{el('ds-stop').hidden=true;}});
  const defaultGoal='이 소자의 용도와 권장 동작 조건, 주요 핀, 응용 회로의 연결을 근거 페이지와 함께 분석해줘. 외부 연결과 한 가지 SPICE 시험을 제안하고, 없는 소자 모델이나 설계 목표 수치는 질문해줘.';
  el('goal-example').onclick=()=>{el('ds-goal').value=defaultGoal;clearAnalysis();sync();};el('ds-goal').oninput=()=>{clearAnalysis();sync();};
  function facts(){el('analysis-card').hidden=false;el('ds-summary').textContent=analysis.summary;el('ds-ai-warnings').textContent=[analysis.meta.model,...analysis.warnings].join(' · ');
    const box=el('ds-fields');box.replaceChildren();
    if(!analysis.fields.length)box.append(node('p','근거 항목이 없습니다. 원본의 전기적 특성 표가 있는 쪽을 선택해 다시 분석하세요.'));
    analysis.fields.forEach((f,i)=>{const div=node('div',null,'factrow'),label=node('label',null,'dscheck'),c=node('input');c.type='checkbox';c.value=i;c.disabled=!f.reader_match;
      c.onchange=()=>{clearDesign();sync();};label.append(c,node('b',f.name+' · '+f.value+' '+f.unit));
      div.append(label,node('small','원본 '+f.page+'쪽 · '+f.kind+' · '+(f.condition||'조건 미기재')),node('blockquote',f.quote||'인용 없음'),
        node('small',!f.reader_match?'인용 불일치 · 선택 불가':f.local_match?'인용 일치 · 로컬 텍스트에서도 찾음':'인용 일치 · 페이지 이미지에서 한 번 더 확인'));box.append(div);});}
  el('ds-analyze').onclick=()=>task(async()=>{const goal=el('ds-goal').value.trim();if(!goal)throw Error('만들려는 회로와 확인할 성능을 적거나 기본 요청을 넣으세요.');
    clearAnalysis();msg('NVIDIA 설계 모델이 완료된 페이지에서 수치와 조건을 찾고 있습니다…');
    analysis=await req('analyze',{doc:info.doc,pages:[...rows.keys()],mode:el('reader-mode').value,goal});facts();msg('근거 '+analysis.fields.length+'개를 받았습니다. 원문을 대조한 항목을 선택하세요.');el('analysis-card').scrollIntoView({block:'start'});});
  el('ds-consent').onchange=()=>{draft=null;el('draft-card').hidden=true;sync();};
  for(const k of ['ds-model-text','ds-educational'])el(k).addEventListener('input',()=>{clearDesign();sync();});
  function showDraft(v,which){draft=v;el('draft-title').textContent=(which||'회로 설계')+(v.status==='draft'?' · 검토할 넷리스트':' · 연결안과 추가 확인');const box=el('draft-body');box.replaceChildren(node('p',v.summary),node('p',v.model+' · SPICE 미검증','draftmeta'));
    for(const [k,title] of [['connections','외부 연결'],['assumptions','설계 가정'],['questions','추가로 필요한 정보'],['warnings','측정 계획과 확인 사항']])if(v[k]?.length){const l=node('ul');v[k].forEach(s=>l.append(node('li',s)));box.append(node('b',title),l);}
    if(v.netlist){const d=node('details');d.append(node('summary','넷리스트 미리보기'),node('pre',v.netlist));box.append(d);}
    el('draft-card').hidden=false;el('draft-apply').hidden=v.status!=='draft';el('draft-card').scrollIntoView({block:'start'});}
  el('ds-design').onclick=()=>task(async()=>{const indices=Array.from(el('ds-fields').querySelectorAll('input:checked')).map(e=>Number(e.value));msg('선택한 원문 근거로 회로 연결안과 측정 계획을 만들고 있습니다…');
    const v=await req('design',{analysis:analysis.analysis,indices,confirmed:el('ds-consent').checked,illustrative:el('ds-educational').checked,model_text:el('ds-model-text').value});
    msg(v.status==='draft'?'회로 초안을 받았습니다. 실제 실행은 편집기에서 시작합니다.':'연결안과 필요한 자료를 확인하세요. 시뮬레이션은 실행하지 않았습니다.');showDraft(v);});
  el('draft-apply').onclick=()=>{if(!draft||draft.status!=='draft')return;if(job?.state==='running')return msg('진행 중인 SPICE 작업이 끝난 뒤 가져오세요.',true);
    window.confirmationId=draft.confirmation_id;loadProject(draft);job=null;selected=0;render();tab('net');view(false);lock(false);
    if(status?.ready)error('');el('netlist').focus();};
  el('refine').onclick=()=>{if(!job?.provenance?.desk)return askAI(true);
    const jid=job.id,idx=selected;view(true);task(async()=>{msg('선택 후보 #'+idx+'의 실제 측정값과 이전 회로를 NVIDIA에 보내고 있습니다…');
      const v=await req('feedback',{job_id:jid,candidate:idx});msg('수정안은 다시 SPICE를 실행해야 검증됩니다.');showDraft(v,job.provenance.sources[0].name+' · 후보 #'+idx+' 피드백');});};
  el('ds-export').onclick=()=>{const out={source:info,original_pages:[...rows.keys()],read:[...rows.values()],analysis,draft,verified_by_spice:false};out.source={...info};delete out.source.doc;
    const u=URL.createObjectURL(new Blob([JSON.stringify(out,null,2)],{type:'application/json'})),a=node('a');a.href=u;a.download='EDAI_datasheet_evidence.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);};
  api('/api/desk/status').then(r=>{cfg=r;if(r.drive.url){const link=el('drive-open');link.href=r.drive.url;link.hidden=false;}window.dsAiReady=r.nvidia;el('nv-status').textContent=r.nvidia?'NVIDIA 키 설정됨 · 호출 전':'NVIDIA 키 미설정 · 로컬 읽기 가능';sync();}).catch(e=>msg(e.message,true));
  api('/api/desk/catalog').then(r=>{el('team-index').hidden=!r.items.length;}).catch(()=>{});
  sync();
})();
