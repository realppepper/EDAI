"""Secrets are entered in the terminal and live for this process only."""
import getpass
import os
import subprocess
import sys
from pathlib import Path
root=Path(__file__).resolve().parent
if not os.getenv('NVIDIA_API_KEY'):
    print('NVIDIA API 키를 붙여넣고 Enter. 입력 문자는 화면에 보이지 않습니다.')
    print('키 없이 로컬 PDF 읽기부터 확인하려면 Enter만 누르세요.')
    key=getpass.getpass('NVIDIA API key: ').strip()
    if key:os.environ['NVIDIA_API_KEY']=key
print('웹 화면에서 데이터시트를 여세요. 이 창을 닫으면 프로그램이 종료됩니다.')
raise SystemExit(subprocess.call([sys.executable,str(root/'server.py')],cwd=root))
