"""Two separate NVIDIA contracts: a page reader and a text reasoning model."""
import base64
import json
import os
import re
import time
import urllib.error
import urllib.request
import uuid
from urllib.parse import urlsplit

CHAT = 'https://integrate.api.nvidia.com/v1/chat/completions'
HOST_MODEL = 'nvidia/nemotron-parse'
NIM_MODEL = 'nvidia/nemotron-3.5-parse'
DEFAULT_DESIGN = 'nvidia/nemotron-3.5-lightning-30b-a3b'
LIMIT = 4 * 1024 * 1024


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('NVIDIA 요청 주소가 바뀌어 중단했습니다.')


def nim_url():
    url = os.getenv('EDAI_NIM_URL', 'http://127.0.0.1:8000/v1/parse').strip()
    u = urlsplit(url)
    if u.hostname not in ('127.0.0.1', 'localhost', '::1') or u.scheme not in ('http','https') or u.path != '/v1/parse' or u.username or u.password or u.query or u.fragment:
        raise ValueError('3.5 전용 NIM은 로컬 /v1/parse 주소를 설정하세요. 원격 NIM은 로컬 포트 포워딩을 사용할 수 있습니다.')
    return url


def analyze_model():
    return os.getenv('EDAI_NVIDIA_DESIGN_MODEL', DEFAULT_DESIGN).strip() or DEFAULT_DESIGN


def has_key():
    return bool(os.getenv('NVIDIA_API_KEY', '').strip())


def request_json(url, body, content_type, cloud):
    headers = {'Content-Type':content_type, 'Accept':'application/json'}
    if cloud:
        key = os.getenv('NVIDIA_API_KEY','').strip()
        if not key:
            raise ValueError('NVIDIA 키가 없습니다. START_WITH_NVIDIA.bat를 열고 실행 창에 키를 입력하세요.')
        headers['Authorization'] = 'Bearer '+key
    req = urllib.request.Request(url, data=body, headers=headers, method='POST')
    try:
        opener=urllib.request.build_opener(NoRedirect)
        deadline=time.monotonic()+150; rid=''
        while True:
            left=deadline-time.monotonic()
            if left<=0:raise ValueError('NVIDIA 응답 대기 시간이 지났습니다. 원래 요청을 재전송하지 않았습니다.')
            with opener.open(req,timeout=max(1,left)) as r:
                rid=rid or r.headers.get('NVCF-REQID') or r.headers.get('x-request-id') or ''
                if getattr(r,'status',200)!=202:
                    data=r.read(LIMIT+1)
                    if len(data)>LIMIT:raise ValueError('모델 응답이 너무 큽니다. 페이지를 나눠 주세요.')
                    out=json.loads(data)
                    if not isinstance(out,dict):raise ValueError('NVIDIA 응답의 형식이 올바르지 않습니다.')
                    return out,rid
                if not cloud:raise ValueError('로컬 NIM에서 페이지 결과가 반환되지 않았습니다.')
                try:rid=str(uuid.UUID(rid or json.loads(r.read(8192)).get('requestId','')))
                except (ValueError,AttributeError,TypeError):
                    raise ValueError('NVIDIA가 대기 상태를 반환했지만 요청 번호가 없습니다.') from None
            req=urllib.request.Request('https://api.nvcf.nvidia.com/v2/nvcf/pexec/status/'+rid,
                  headers={'Authorization':headers['Authorization'],'Accept':'application/json','NVCF-POLL-SECONDS':'8'})
            time.sleep(.4)
    except urllib.error.HTTPError as e:
        hints={400:'요청 또는 모델 형식을 확인하세요.',401:'NVIDIA 실행 창에 넣은 키를 확인하세요.',402:'NVIDIA 계정의 사용 한도를 확인하세요.',403:'이 키에 모델 접근 권한이 있는지 확인하세요.',404:'모델 또는 NIM 주소를 확인하세요.',410:'이 호스팅 모델의 서비스가 종료되었습니다. 다른 지원 모델 또는 3.5 NIM을 사용하세요.',413:'페이지 이미지가 너무 큽니다. 해상도가 낮은 사본을 선택하세요.',429:'호출 한도에 도달했습니다. 잠시 후 다시 시도하세요.'}
        raise ValueError(f'NVIDIA HTTP {e.code}: '+hints.get(e.code,'서비스가 요청을 완료하지 못했습니다.')) from None
    except (urllib.error.URLError,TimeoutError):
        raise ValueError('NVIDIA 연결 실패 또는 시간 초과. 서버·인터넷 연결을 확인하세요. 자동으로 다시 과금 요청하지 않습니다.') from None
    except (json.JSONDecodeError, UnicodeError):
        raise ValueError('NVIDIA에서 읽을 수 있는 JSON 응답을 받지 못했습니다.') from None


def cloud_json(payload):
    return request_json(CHAT,json.dumps(payload,ensure_ascii=False).encode(),'application/json',True)


def item_text(node):
    if isinstance(node,str): return node
    if isinstance(node,list): return '\n'.join(s for x in node if (s:=item_text(x)))
    if isinstance(node,dict):
        for key in ('text','markdown','content','elements','items','data','markdown_bbox','blocks','records','bounding_boxes','bboxes','page_elements','predictions','regions'):
            if key in node:
                t=item_text(node[key])
                if t: return t
    return ''


def parse_page(image, mode, mime):
    start=time.monotonic()
    if mode=='native':
        b='edai'+uuid.uuid4().hex
        ext='jpg' if mime=='image/jpeg' else 'png'
        body=(f'--{b}\r\nContent-Disposition: form-data; name="document"; filename="page.{ext}"\r\nContent-Type: {mime}\r\n\r\n').encode()+image+f'\r\n--{b}--\r\n'.encode()
        data,rid=request_json(nim_url(),body,'multipart/form-data; boundary='+b,False)
        raw=data.get('content',''); finish=data.get('finish_reason'); name=NIM_MODEL
    elif mode=='build':
        name=HOST_MODEL
        uri='data:'+mime+';base64,'+base64.b64encode(image).decode('ascii')
        tool={'type':'function','function':{'name':'markdown_bbox'}}
        payload={'model':name,'messages':[{'role':'user','content':[{'type':'image_url','image_url':{'url':uri}}]}],
                 'tools':[tool],'tool_choice':tool,'stream':False,'temperature':0}
        data,rid=cloud_json(payload)
        try:
            choice=data['choices'][0]; msg=choice['message']; finish=choice.get('finish_reason')
            calls=msg.get('tool_calls',[]); records=[]
            for call in calls:
                fun=call.get('function',{})
                if fun.get('name')!='markdown_bbox':continue
                val=fun.get('arguments','')
                records.append(json.loads(val) if isinstance(val,str) else val)
            raw=item_text(records) or item_text(msg.get('content'))
        except (KeyError,IndexError,TypeError,AttributeError,json.JSONDecodeError):
            raise ValueError('NVIDIA Build의 문서 응답을 읽지 못했습니다. 원본과 로컬 텍스트는 그대로 남아 있습니다.') from None
    else:
        raise ValueError('문서 읽기 방식을 선택하세요.')
    if finish in ('length','max_tokens'):raise ValueError('문서 응답이 중간에 잘렸습니다. 원본에서 더 작은 영역을 선택해 다시 시도하세요.')
    if not isinstance(raw,str) or not raw.strip():raise ValueError('선택한 페이지에서 NVIDIA가 텍스트를 반환하지 않았습니다.')
    clean=re.sub(r'<(?:x_[\d.]+|y_[\d.]+|class_[^>]+)>','',raw).strip()
    if not clean:raise ValueError('인식된 텍스트가 없습니다.')
    return clean,{'model':str(data.get('model') or name),'requested_model':name,'mode':mode,'request_id':rid,
                  'latency_s':round(time.monotonic()-start,2),'finish_reason':finish,'usage':data.get('usage',{})}


def reason(system,payload):
    # Only text is sent to this endpoint. PDF bytes, keys and workstation paths aren't included.
    model=analyze_model()
    data,rid=cloud_json({'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(payload,ensure_ascii=False)}],
                         'temperature':0.15,'max_tokens':8192,'stream':False,
                         **({'chat_template_kwargs':{'enable_thinking':False}} if model==DEFAULT_DESIGN else {})})
    try:
        choice=data['choices'][0]; txt=choice['message'].get('content')
        if choice.get('finish_reason')=='length':raise ValueError('설계 모델 응답이 잘렸습니다. 페이지나 요구사항 수를 줄여 주세요.')
        if not isinstance(txt,str) or not txt.strip():raise ValueError('설계 모델의 답변이 비어 있습니다.')
        txt=re.sub(r'^\s*<think>.*?</think>\s*','',txt,flags=re.S)
        txt=re.sub(r'^\s*```(?:json)?\s*|\s*```\s*$','',txt.strip(),flags=re.I)
        result=json.loads(txt)
        if not isinstance(result,dict):raise ValueError('모델이 JSON 객체를 반환하지 않았습니다.')
        return result,{'model':str(data.get('model') or model),'requested_model':model,'request_id':rid}
    except (KeyError,IndexError,TypeError,json.JSONDecodeError,AttributeError):
        raise ValueError('설계 모델의 응답 형식이 잘못되었습니다. 추출 결과는 유지됩니다. 요청을 더 구체적으로 입력해 주세요.') from None
