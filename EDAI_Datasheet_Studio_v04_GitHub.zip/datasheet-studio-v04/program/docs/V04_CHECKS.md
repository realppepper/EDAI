# 데이터시트 작업실 v0.4 · 검증 기록

날짜: 2026-11-18. 코드, 팀 폴더의 실제 파일, 외부 서비스를 대신한 테스트 응답을 아래처럼 구분한다.

| 구간 | 확인 방법 | 관찰한 내용 |
|---|---|---|
| 임의 자료 | 사용자가 별도 제공한 cdcvf2505-q1.pdf를 등록, 로컬 읽기 | 15쪽으로 인식. 1쪽과 마지막 15쪽을 원본 쪽번호 그대로 읽음. 회로 종류나 정답 수치 사전 설정 없음. |
| 인증·문서 API 계약 | NVIDIA 네트워크를 모의 응답으로 대체 | 호스팅은 이미지+markdown_bbox 도구 결과, native는 단일 이미지 multipart. 빈 응답/실패를 유효한 결과로 임의 대체하지 않음. 추출 텍스트 불일치 인용이 선택되지 않음. |
| 자료 → 측정 → 피드백 | 실제 로컬 HTTP 서버, Google API·NVIDIA는 모의 응답, **ngspice는 실제 실행** | 같은 실제 PDF의 직접 업로드·Drive 경로, 원본 3쪽 미리보기, 1·17쪽 읽기, 조건 확인, 모델 없는 설계의 연결안 제한, 교육용 초안, 실행 결과 ZIP의 출처, 선택 후보의 측정값으로 피드백 재요청을 확인. |
| 시뮬레이션 수치 | 테스트 전용 이상 증폭기 입력 0.1 V·이득 약 2, 실제 ngspice | 후보 출력 0.199996 V. 이 수치는 HTTP 연결 시험용 회로의 측정값이며, TLV271의 제조사 모델 결과도 실물 측정도 아님. UI에서 보이지 않는 사전 계산값이 아님. |
| 기존 오류 회귀 검사 | 예전 LTspice 로그의 WHEN, FIND, MAX 예시 | 단독 WHEN은 당시 시점 약 1.0001 µs, FIND/MAX는 측정값을 사용. 첫 교차를 정착시간으로 재정의한 것은 아님. |
| 자동 검사 | unittest 20개(실제 ngspice가 필요한 테스트 포함), 별도 HTTP 통합 검사, Python/JS 구문 검사 | 모두 통과. HTML에 새 JS가 참조하는 컨트롤 ID가 있는지도 검사함. |

이 환경에는 사용자의 NVIDIA 실키나 로컬 프로그램용 Google 데스크톱 OAuth 클라이언트가 없어서 실제 NVIDIA 모델 출력 및 새 앱의 Google OAuth 실로그인은 검증하지 않았다. 문서 목록을 실제로 조회하고 팀 PDF를 내려받은 것과 이 두 가지는 별도다. Windows LTspice 재실행과 실제 브라우저 클릭 전체 흐름은 미검증이다(로컬 Chromium 시작 제한). 전체 UI를 따로 확인하는 선택적 스크립트 `tests/check_desk_browser.py`가 포함되어 있다. 공개본에서는 팀 폴더 ID, 카탈로그 실데이터, 팀 원본 PDF, API 키, 로그인 정보 및 가상환경을 제외한다.

재현: PyMuPDF 설치 후 `python -m unittest discover -s tests` 실행. 실제 ngspice 검사에는 `EDAI_TEST_NGSPICE`를 실행 파일 경로로 지정한다. 통합 검사는 `EDAI_TEST_PDF`에 팀 TLV271.PDF 경로를 설정하고 `python tests/check_desk_browser.py --http-only`를 실행한다. 브라우저 검사 시에는 Playwright + Chromium을 설치하고 `--http-only`를 생략한다.
