@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
if not exist ".venv\Scripts\python.exe" (
    where py >nul 2>nul
    if errorlevel 1 (
        python -m venv .venv
    ) else (
        py -3 -m venv .venv
    )
)
if not exist ".venv\Scripts\python.exe" goto no_python
".venv\Scripts\python.exe" -c "import pymupdf, google_auth_oauthlib" >nul 2>nul
if errorlevel 1 (
    echo Installing PDF and optional Google Drive support in .venv ...
    ".venv\Scripts\python.exe" -m pip install -r requirements-ai.txt
    if errorlevel 1 goto install_error
)
".venv\Scripts\python.exe" start_with_nvidia.py
goto finish
:no_python
echo Python 3.10+ is required. Install Python, then reopen this file.
goto finish
:install_error
echo Package installation failed. Check your internet connection, then reopen.
:finish
pause
