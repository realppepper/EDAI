# NVIDIA 데이터시트 작업실

v0.4에서는 [README_KO.md](README_KO.md)의 **3. 문서 모델과 설계 모델**을 따르세요. 실행 파일은 `START_WITH_NVIDIA.bat`입니다. 기본 클라우드 사용은 키만 입력하고, 팀에 별도 3.5 Parse NIM이 있을 때만 native 방식을 선택하세요. 구버전 OpenRouter 설정란에는 NVIDIA 키를 넣지 않습니다.
