"""Read-only Drive v3; the local app never reuses browser cookies or sends Google credentials to NVIDIA."""
import json
import os
import re
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT_ID=os.environ.get('EDAI_DRIVE_FOLDER_ID','').strip()
if not re.fullmatch(r'[A-Za-z0-9_-]{5,160}',ROOT_ID):
    ROOT_ID=''
FOLDER='application/vnd.google-apps.folder'
PDF='application/pdf'
MAX_BYTES=24*1024*1024
BASE='https://www.googleapis.com/drive/v3/files'
SCOPE='https://www.googleapis.com/auth/drive.readonly'
LOCK=threading.RLock()
AUTH_LOCK=threading.Lock()
creds=None
catalog={ROOT_ID:{'id':ROOT_ID,'name':'공유 폴더','mimeType':FOLDER}} if ROOT_ID else {}


def client_path():
    return Path(os.environ.get('EDAI_GOOGLE_CLIENT','') or (Path(__file__).parent/'drive-client.json'))


def state():
    return {'connected':bool(ROOT_ID) and (creds is not None or bool(os.getenv('GOOGLE_DRIVE_API_KEY'))),
            'can_login':bool(ROOT_ID) and client_path().is_file(),'root':ROOT_ID,'url':'https://drive.google.com/drive/folders/'+ROOT_ID if ROOT_ID else ''}


def login():
    global creds
    if not ROOT_ID:raise ValueError('EDAI_DRIVE_FOLDER_ID를 설정한 뒤 다시 실행하세요.')
    if not AUTH_LOCK.acquire(False):raise ValueError('이미 Google 로그인을 진행 중입니다.')
    try:
        if not client_path().is_file():raise ValueError('Google Desktop OAuth 설정(drive-client.json)이 없습니다. Google Drive에서 PDF를 내려받아 ‘내 파일’로 열거나 동기화 폴더를 선택하세요.')
        try: from google_auth_oauthlib.flow import InstalledAppFlow
        except ImportError: raise ValueError('INSTALL_PDF_SUPPORT.bat를 실행한 뒤 다시 시작하세요.') from None
        try:
            cfg=json.loads(client_path().read_text(encoding='utf-8-sig'))
            desktop=cfg.get('installed',{})
            if desktop.get('auth_uri') not in ('https://accounts.google.com/o/oauth2/auth','https://accounts.google.com/o/oauth2/v2/auth') or desktop.get('token_uri')!='https://oauth2.googleapis.com/token':
                raise ValueError
            flow=InstalledAppFlow.from_client_config(cfg,[SCOPE],autogenerate_code_verifier=True)
            new=flow.run_local_server(host='127.0.0.1',port=0,timeout_seconds=180,
                authorization_prompt_message=None,success_message='Google Drive connected. Return to EDAI.',
                access_type='online',open_browser=True)
        except Exception:raise ValueError('Google 로그인에 실패했거나 시간이 지났습니다. Drive API, 테스트 사용자, 데스크톱 OAuth 파일 및 읽기 권한을 확인하세요.') from None
        with LOCK:creds=new
        return state()
    finally:AUTH_LOCK.release()


class DriveRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        u=urllib.parse.urlsplit(newurl)
        if u.scheme!='https' or not (u.hostname=='www.googleapis.com' or (u.hostname or '').endswith('.googleusercontent.com')):
            raise ValueError('Google의 정식 다운로드 주소가 아니어서 중단했습니다.')
        nxt=super().redirect_request(req,fp,code,msg,headers,newurl)
        if nxt and u.hostname!=urllib.parse.urlsplit(req.full_url).hostname:
            for k in ('Authorization','X-goog-api-key','X-goog-drive-resource-keys'):nxt.remove_header(k)
        return nxt


def get_bytes(path,params,resource='',bound=2*1024*1024):
    with LOCK:
        credentials=creds
        headers={'Accept':'*/*'}
        if credentials is not None:
            try:
                from google.auth.transport.requests import Request
                credentials.before_request(Request(),'GET',BASE+path,headers)
            except Exception:raise ValueError('Google 로그인이 만료되었습니다. Drive에 다시 연결하세요.') from None
        elif os.getenv('GOOGLE_DRIVE_API_KEY'):
            headers['X-Goog-Api-Key']=os.environ['GOOGLE_DRIVE_API_KEY']
        else:raise ValueError('팀 폴더 직접 연결에는 Google 읽기 권한이 필요합니다. Drive 로그인 또는 아래의 다운로드·동기화 폴더 방식을 사용하세요.')
    if resource:headers['X-Goog-Drive-Resource-Keys']=resource
    req=urllib.request.Request(BASE+path+'?'+urllib.parse.urlencode(params),headers=headers)
    try:
        with urllib.request.build_opener(DriveRedirect).open(req,timeout=45) as r:
            if int(r.headers.get('Content-Length') or 0)>bound:raise ValueError('선택 파일이 앱의 용량 제한을 넘습니다.')
            data=r.read(bound+1)
            if len(data)>bound:raise ValueError('Google 응답이 용량 제한을 넘습니다.')
            return data
    except urllib.error.HTTPError as e:
        raise ValueError(f'Google Drive HTTP {e.code}. '+{401:'로그인을 다시 하세요.',403:'공유 대상 계정과 Drive API 사용 설정을 확인하세요.',404:'파일이 이동했거나 접근할 권한이 없습니다.',429:'Drive 요청 한도에 도달했습니다.'}.get(e.code,'다운로드 권한과 연결을 확인하세요.')) from None
    except (TimeoutError,urllib.error.URLError):raise ValueError('Google Drive 연결 실패. 팀 폴더에서 내려받고 내 파일로 열 수 있습니다.') from None


def known(id_,folder):
    with LOCK: item=catalog.get(id_)
    if not item or item['mimeType']!=(FOLDER if folder else PDF):raise ValueError('팀 폴더의 목록을 새로 열고 항목을 선택하세요.')
    return item


def rkey(item):
    key=item.get('resourceKey','')
    return item['id']+'/'+key if key and re.fullmatch(r'[\w-]+',key) else ''


def listing(data):
    if not ROOT_ID:raise ValueError('EDAI_DRIVE_FOLDER_ID를 설정한 뒤 다시 실행하세요.')
    parent=known(data.get('folder') or ROOT_ID,True); fid=parent['id']
    query={'q':f"'{fid}' in parents and trashed = false and (mimeType = '{PDF}' or mimeType = '{FOLDER}')",
         'pageSize':100,'fields':'nextPageToken,incompleteSearch,files(id,name,mimeType,size,modifiedTime,resourceKey,capabilities(canDownload))',
         'orderBy':'folder,name_natural','supportsAllDrives':'true','includeItemsFromAllDrives':'true'}
    tok=data.get('next','')
    if tok:query['pageToken']=str(tok)[:4096]
    raw=json.loads(get_bytes('',query,rkey(parent)));items=[]
    for f in raw.get('files',[]):
        if f.get('mimeType') not in (PDF,FOLDER) or not re.fullmatch(r'[a-zA-Z0-9_-]{5,160}',str(f.get('id',''))):continue
        with LOCK:catalog[f['id']]=f
        items.append({'id':f['id'],'name':f['name'],'folder':f['mimeType']==FOLDER,
                      'size':int(f.get('size') or 0),'modified':f.get('modifiedTime','')[:10],
                      'downloadable':f.get('capabilities',{}).get('canDownload',True)})
    return {'items':items,'next':raw.get('nextPageToken',''),'incomplete':bool(raw.get('incompleteSearch'))}


def download(file_id):
    f=known(file_id,False)
    if not f.get('capabilities',{}).get('canDownload',True):raise ValueError('소유자가 다운로드를 허용하지 않았습니다.')
    if int(f.get('size') or 0)>MAX_BYTES:raise ValueError('PDF는 24 MiB 이하로 선택하세요.')
    data=get_bytes('/'+file_id,{'alt':'media','supportsAllDrives':'true'},rkey(f),MAX_BYTES)
    if b'%PDF-' not in data[:1024]:raise ValueError('Drive에서 PDF 파일 본문을 받지 못했습니다.')
    return f['name'],data
