# EDAI Datasheet Studio v0.4

팀 통합 검토용 독립 버전입니다. PDF 원문 열기와 출처 확인, 회로 초안, SPICE 측정 및 결과 기반 피드백 흐름을 제공합니다.

Windows에서는 `program/START_WITH_NVIDIA.bat`를 실행하세요. NVIDIA 키 입력을 생략해 PyMuPDF로 먼저 읽을 수 있습니다. Drive 직접 연결은 폴더 ID와 Google 인증을 실행하는 PC에서 설정하세요.

- [설치 및 실행 안내](program/README_KO.md)
- [기능 검증 기록](program/docs/V04_CHECKS.md)

상용 소자의 실제 성능은 해당 SPICE 모델과 테스트벤치로 별도 검증하세요.
