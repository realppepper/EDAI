@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  .venv\Scripts\python.exe server.py
) else (
  where py >nul 2>nul
  if errorlevel 1 (python server.py) else (py -3 server.py)
)
pause
