"""Offline reproduction of the observed LTspice WHEN parsing issue.
The log line is a screenshot transcription, not a new simulation result.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from engine import parse_measurements

line = "settling_time: V(VOUT)=0.098 AT 1.00010459867e-06"
current = parse_measurements(line, ["settling_time"]).get("settling_time")
event_time = 1.00010459867e-06
print("Observed log:", line)
print("Current parser:", current)
print("Log event time:", event_time)
print("Known issue reproduced:", current == 0.098 and current != event_time)
print("The event time itself is not a validated settling time.")
