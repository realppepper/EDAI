# 빠른 실행

최신 안내는 README_KO.md입니다. 이 파일과 함께 제공된 코드 전체를 압축 해제하세요.

1. Python 3.10 이상, LTspice를 설치합니다.
2. INSTALL_PDF_SUPPORT.bat을 실행합니다.
3. START_WINDOWS.bat으로 로컬 화면을 엽니다.
4. AI 호출은 서버 종료 후 START_WITH_AI.bat으로 실행합니다.
5. 팀원이 각자 모델 접근권한과 API 키를 준비합니다.

알려진 측정 파싱 오류와 교육용 회로 한계는 docs/KNOWN_ISSUES.md에 있습니다.
