import base64,io,json,os,sys,tempfile,threading,time,unittest,urllib.request,urllib.error,zipfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from review import extract,validate_confirmation
ROOT=Path(__file__).resolve().parents[1]

class ReviewTests(unittest.TestCase):
    def test_pdf_pages_and_confirmation(self):
        import pymupdf
        doc=pymupdf.open();p=doc.new_page();p.insert_text((40,40),'TEST ONLY. VDD typical 5 V. Not a design goal.')
        data={'files':[{'name':'fixture.pdf','base64':base64.b64encode(doc.tobytes()).decode()}]}
        result=extract(data,{})
        self.assertEqual(result['pages'][0]['page'],1)
        self.assertIn('Not a design goal',result['pages'][0]['text'])
        self.assertEqual(result['fields'],[])
        with self.assertRaises(ValueError):validate_confirmation({'goals':'gain 12'},result)
        self.assertTrue(validate_confirmation({'confirmed':True,'goals':'gain 12','fields':[]},result)['user_confirmed'])
    def test_ai_quote_and_false_citation(self):
        data={'files':[{'name':'fixture.txt','base64':base64.b64encode(b'VDD typical 5 V').decode()}],'use_ai':True}
        rows=[{'name':'VDD','value':'5','unit':'V','kind':'typ','source':'fixture.txt','page':1,'quote':'VDD typical 5 V'},
              {'name':'VDD','source':'invented.pdf','page':99,'quote':'5 V'}]
        class Fake:
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def read(self,*a):return json.dumps({'choices':[{'message':{'content':json.dumps({'fields':rows,'warnings':[]})}}]}).encode()
        with patch.dict(os.environ,{'EDAI_TEST_KEY':'offline-test'}),patch('urllib.request.urlopen',lambda *a,**k:Fake()):
            r=extract(data,{'ai':{'model':'offline-test','api_key_env':'EDAI_TEST_KEY'}})
        self.assertEqual(r['fields'][0]['evidence_status'],'text_match')
        self.assertEqual(r['fields'][1]['evidence_status'],'manual_check_required')

@unittest.skipUnless(os.environ.get('EDAI_TEST_NGSPICE'),'Actual ngspice path required')
class HTTPWorkflow(unittest.TestCase):
    def test_review_run_and_export(self):
        import server
        import shutil
        original=server.ROOT
        with tempfile.TemporaryDirectory() as folder:
            server.ROOT=Path(folder);shutil.copytree(ROOT/'examples',server.ROOT/'examples')
            server.CONFIG={'simulator':'ngspice','simulator_path':os.environ['EDAI_TEST_NGSPICE']}
            http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
            server.PORT=http.server_port;server.ORIGIN=f'http://127.0.0.1:{server.PORT}'
            thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
            def call(path,data=None,raw=False):
                req=urllib.request.Request(server.ORIGIN+path,data=json.dumps(data).encode() if data is not None else None,headers={'X-EDAI-Token':server.TOKEN,'Content-Type':'application/json'})
                with urllib.request.urlopen(req,timeout=15) as r:b=r.read()
                return b if raw else json.loads(b)
            try:
                result=call('/api/extract',{'files':[{'name':'requirements.txt','base64':base64.b64encode(b'Educational NMOS example. Gain >=12. Power <=0.6 mW.').decode()}]})
                cid=call('/api/confirm',{'review_id':result['review_id'],'goals':'educational NMOS gain >=12','fields':[],'confirmed':True})['confirmation_id']
                p=call('/api/example');p['confirmation_id']=cid
                jid=call('/api/run',p)['id'];deadline=time.monotonic()+20
                while True:
                    job=call('/api/jobs/'+jid)
                    if job['state']!='running':break
                    if time.monotonic()>deadline:self.fail('run timeout')
                    time.sleep(.1)
                self.assertEqual(job['state'],'completed');self.assertEqual(len(job['runs']),32)
                best=job['runs'][job['best_iteration']];self.assertTrue(best['feasible'])
                z=zipfile.ZipFile(io.BytesIO(call('/api/jobs/'+jid+'/download',raw=True)))
                self.assertTrue(json.loads(z.read('document_review.json'))['user_confirmed'])
                self.assertIn('best.cir',z.namelist());self.assertIn('summary.json',z.namelist())
                evidence={'date':'2026-11-04','engine':'ngspice','runs':len(job['runs']),'feasible_count':job['feasible_count'],'best_iteration':job['best_iteration'],'initial':job['runs'][0]['metrics'],'selected':best['metrics'],'verified':['document local extraction','confirmation','HTTP actual run','document provenance ZIP'],'not_verified':['live AI API','Windows LTspice','browser rendering']}
                (ROOT/'validation/v03_verification.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
            finally:http.shutdown();http.server_close();server.ROOT=original

if __name__=='__main__':unittest.main()
