import base64
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import validate_project,validate_netlist,parse_measurements,assess,run_spice,optimize
from ai_input import generate
ROOT=Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'examples/common_source.cir').read_text(encoding='utf-8')
SETTINGS=json.loads((ROOT/'examples/common_source.json').read_text(encoding='utf-8'))

class Contracts(unittest.TestCase):
    def test_rejects_commands_and_bad_bounds(self):
        for command in ['.control\nshell whoami\n.endc','.include secret.txt','.step param RD list 1k 2k']:
            with self.assertRaises(ValueError):validate_netlist(SOURCE.replace('.end',command+'\n.end'))
        s=json.loads(json.dumps(SETTINGS));s['parameters'][0]['min']=100000
        with self.assertRaises(ValueError):validate_project(SOURCE,s)
    def test_two_log_dialects_and_missing_is_failure(self):
        self.assertEqual(parse_measurements('gain = 1.23e+01\npower_mw: -5*iavg*1000=0.4\n',['gain','power_mw']),{'gain':12.3,'power_mw':.4})
        r={'metrics':{'gain':99},'error':None}
        assess(r,SETTINGS);self.assertFalse(r['valid']);self.assertFalse(r['feasible'])
    def test_ai_payload_and_output_contract_without_network(self):
        answer={'summary':'test','netlist':SOURCE,'settings':SETTINGS,'assumptions':['educational model'],'evidence':[],'warnings':[]}
        class Fake:
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def read(self,*a):return json.dumps({'choices':[{'message':{'content':json.dumps(answer)}}]}).encode()
        seen=[]
        def mock(req,**kwargs):
            seen.append(json.loads(req.data));return Fake()
        with patch.dict(os.environ,{'EDAI_TEST_KEY':'dummy-for-offline-test'}),patch('urllib.request.urlopen',mock):
            r=generate({'instruction':'make a circuit','files':[{'name':'test.png','base64':base64.b64encode(b'not-sent-to-network').decode()}]},
                {'simulator':'ngspice','ai':{'provider':'openrouter','model':'test/vision','api_key_env':'EDAI_TEST_KEY'}})
        self.assertFalse(r['verified_by_spice'])
        self.assertEqual(seen[0]['messages'][1]['content'][-1]['type'],'image_url')

@unittest.skipUnless(os.environ.get('EDAI_TEST_NGSPICE'),'Set EDAI_TEST_NGSPICE to run real simulator tests.')
class RealSpice(unittest.TestCase):
    def setUp(self):self.cfg={'simulator':'ngspice','simulator_path':os.environ['EDAI_TEST_NGSPICE']}
    def test_feedback_and_saved_provenance(self):
        with tempfile.TemporaryDirectory() as d:
            r=optimize(SOURCE,SETTINGS,self.cfg,Path(d))
            self.assertEqual(len(r['runs']),32)
            best=r['runs'][r['best_iteration']]
            self.assertTrue(best['feasible']);self.assertGreaterEqual(best['metrics']['gain'],12)
            self.assertLess(best['metrics']['power_mw'],r['runs'][0]['metrics']['power_mw'])
            self.assertGreater(best['waveform']['total_points'],100)
            self.assertEqual(hashlib.sha256((Path(d)/'best.cir').read_bytes()).hexdigest(),best['source_sha256'])
    def test_failed_measure_is_not_pass(self):
        with tempfile.TemporaryDirectory() as d:
            broken=SOURCE.replace(".meas tran gain PARAM='vout_pp/vin_pp'",'.meas tran gain FIND V(out) AT=99')
            r=run_spice(broken,{'RD':10000,'VG':1.1},self.cfg,Path(d)/'missing')
            assess(r,SETTINGS);self.assertFalse(r['valid']);self.assertIn('gain',r['missing_measures'])
    def test_impossible_target(self):
        with tempfile.TemporaryDirectory() as d:
            s=json.loads(json.dumps(SETTINGS));s['goals'][0]['value']=10000;s['max_runs']=5
            r=optimize(SOURCE,s,self.cfg,Path(d))
            self.assertEqual(r['feasible_count'],0)
            self.assertIsNotNone(r['best_iteration'])

if __name__=='__main__':unittest.main(verbosity=2)
