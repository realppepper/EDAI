@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  .venv\Scripts\python.exe start_with_ai.py
) else (
  py -3 start_with_ai.py
)
pause
