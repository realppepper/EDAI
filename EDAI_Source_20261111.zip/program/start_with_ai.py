"""Prompt locally; keep the API key in this process environment only."""
import getpass,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
path=root/'config.json'
cfg=json.loads((path if path.exists() else root/'config.example.json').read_text(encoding='utf-8-sig'))
print('EDAI: OpenRouter image-capable model ID and API key are required.')
model=input('Model ID (blank = keep existing): ').strip()
if model:cfg.setdefault('ai',{})['model']=model
if not cfg.get('ai',{}).get('model'):raise SystemExit('No model ID. Run START_WINDOWS.bat for API-free SPICE.')
key=getpass.getpass('OpenRouter API key (hidden, not saved): ').strip()
if not key:raise SystemExit('No API key. Run START_WINDOWS.bat for API-free SPICE.')
cfg['ai']['provider']='openrouter';cfg['ai']['api_key_env']='OPENROUTER_API_KEY'
path.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
os.environ['OPENROUTER_API_KEY']=key
raise SystemExit(subprocess.call([sys.executable,str(root/'server.py')],cwd=root))
