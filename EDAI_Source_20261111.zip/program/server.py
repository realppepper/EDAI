"""Loopback-only local UI. Run: python server.py. Core has no pip dependency."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import copy
import csv
import io
import json
import mimetypes
import os
import secrets
import threading
import time
import urllib.parse
import webbrowser
import zipfile
from engine import optimize,resolve_simulator,validate_project
from ai_input import generate,prepare_sources
from review import extract,validate_confirmation

ROOT=Path(__file__).resolve().parent
TOKEN=secrets.token_urlsafe(24)
LOCK=threading.RLock();JOBS={};AI_LOCK=threading.Lock()
REVIEWS={};CONFIRMATIONS={}

def load_config():
    path=ROOT/'config.json'
    if not path.exists():
        cfg=json.loads((ROOT/'config.example.json').read_text(encoding='utf-8'))
        if os.name!='nt':cfg['simulator']='ngspice'
        path.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
    return json.loads(path.read_text(encoding='utf-8-sig'))

CONFIG=load_config()
PORT=int(CONFIG.get('port',8765))
if not 1024<=PORT<=65535:raise ValueError('port는 1024~65535여야 합니다.')
ORIGIN=f'http://127.0.0.1:{PORT}'

def public_job(job):
    return {k:copy.deepcopy(v) for k,v in job.items() if k not in ('cancel','folder')}

def work(job,source,settings):
    def update(r,best):
        with LOCK:
            job['runs'].append(r);job['best_iteration']=best['iteration'] if best else None
    try:
        result=optimize(source,settings,CONFIG,job['folder'],update,job['cancel'])
        with LOCK:
            job['state']='cancelled' if result['cancelled'] else 'completed'
            job['feasible_count']=result['feasible_count']
    except Exception as exc:
        with LOCK:job['state']='failed';job['error']=str(exc)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def send(self,data,status=200,mime='application/json; charset=utf-8',download=None):
        if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status)
        self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; worker-src 'self' blob:; connect-src 'self' blob:; frame-ancestors 'none'; base-uri 'none'")
        if download:self.send_header('Content-Disposition','attachment; filename="'+download+'"')
        self.end_headers();self.wfile.write(data)
    def guard(self,post=False):
        if self.headers.get('Host')!=f'127.0.0.1:{PORT}':
            self.send({'error':'127.0.0.1 주소로 접속해 주세요.'},403);return False
        origin=self.headers.get('Origin')
        if origin and origin!=ORIGIN:
            self.send({'error':'외부 사이트 요청은 허용하지 않습니다.'},403);return False
        if post and self.headers.get('X-EDAI-Token')!=TOKEN:
            self.send({'error':'페이지를 새로고침해 주세요.'},403);return False
        return True
    def do_GET(self):
        if not self.guard():return
        path=urllib.parse.urlsplit(self.path).path
        try:
            if path=='/bootstrap.js':
                return self.send(('window.EDAI_TOKEN='+json.dumps(TOKEN)+';').encode(),mime='text/javascript')
            if path=='/api/status':
                try:engine,exe=resolve_simulator(CONFIG);ready=True;error=None
                except ValueError as exc:engine=CONFIG.get('simulator');ready=False;error=str(exc)
                ai=CONFIG.get('ai',{})
                return self.send({'simulator':engine,'ready':ready,'error':error,
                       'ai_ready':bool(ai.get('model') and os.environ.get(ai.get('api_key_env','OPENROUTER_API_KEY'))),
                       'ai_model':ai.get('model',''),'version':'0.3-local'})
            if path=='/api/settings':
                return self.send({'simulator':CONFIG.get('simulator'),'simulator_path':CONFIG.get('simulator_path',''),'model':CONFIG.get('ai',{}).get('model','')})
            if path.startswith('/studio/'):
                rel=urllib.parse.unquote(path[len('/studio/'):]) or 'index.html'
                base=(ROOT/'web/studio').resolve();p=(base/rel).resolve()
                if not p.is_relative_to(base) or not p.is_file():return self.send({'error':'없는 경로'},404)
                return self.send(p.read_bytes(),mime=mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
            if path=='/api/example':
                return self.send({'netlist':(ROOT/'examples/common_source.cir').read_text(encoding='utf-8'),
                                  'settings':json.loads((ROOT/'examples/common_source.json').read_text(encoding='utf-8'))})
            if path.startswith('/api/jobs/'):
                parts=path.split('/');jid=parts[3]
                with LOCK:
                    if jid not in JOBS:return self.send({'error':'작업을 찾을 수 없습니다.'},404)
                    job=JOBS[jid]
                    if len(parts)==4:return self.send(public_job(job))
                    if len(parts)==5 and parts[4]=='download':
                        if job['state']=='running':return self.send({'error':'실행 종료 후 다운로드해 주세요.'},409)
                        mem=io.BytesIO()
                        with zipfile.ZipFile(mem,'w',zipfile.ZIP_DEFLATED) as z:
                            for p in job['folder'].rglob('*'):
                                if p.is_file():z.write(p,p.relative_to(job['folder']))
                        return self.send(mem.getvalue(),mime='application/zip',download='EDAI_SPICE_'+jid+'.zip')
                return self.send({'error':'없는 경로입니다.'},404)
            allowed={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/style.css':'style.css','/review.js':'review.js'}
            if path in allowed:
                p=ROOT/'web'/allowed[path]
                return self.send(p.read_bytes(),mime=mimetypes.guess_type(p.name)[0] or 'text/plain')
            self.send({'error':'없는 경로입니다.'},404)
        except Exception as exc:self.send({'error':str(exc)},500)
    def do_POST(self):
        if not self.guard(post=True):return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=15_000_000:return self.send({'error':'요청 크기 제한: 15 MB'},413)
            data=json.loads(self.rfile.read(size))
            if self.path=='/api/settings':
                with LOCK:
                    if any(j['state']=='running' for j in JOBS.values()) or AI_LOCK.locked():raise ValueError('실행 중에는 설정을 변경할 수 없습니다.')
                    engine=data.get('simulator')
                    if engine not in ('ngspice','ltspice'):raise ValueError('시뮬레이터 선택 오류')
                    CONFIG['simulator']=engine;CONFIG['simulator_path']=str(data.get('simulator_path','')).strip()
                    CONFIG.setdefault('ai',{})['model']=str(data.get('model','')).strip()[:200]
                    (ROOT/'config.json').write_text(json.dumps(CONFIG,ensure_ascii=False,indent=2),encoding='utf-8')
                return self.send({'ok':True})
            if self.path=='/api/extract':
                if not AI_LOCK.acquire(blocking=False):raise ValueError('자료 처리 중입니다.')
                try:result=extract(data,CONFIG)
                finally:AI_LOCK.release()
                rid=secrets.token_hex(16)
                with LOCK:
                    if len(REVIEWS)>=10:REVIEWS.pop(next(iter(REVIEWS)))
                    REVIEWS[rid]=result
                return self.send({**result,'review_id':rid})
            if self.path=='/api/confirm':
                with LOCK:
                    review=REVIEWS.get(data.get('review_id'))
                    if not review:raise ValueError('문서를 다시 추출해 주세요.')
                    snapshot=validate_confirmation(data,review);cid=secrets.token_hex(16)
                    if len(CONFIRMATIONS)>=20:CONFIRMATIONS.pop(next(iter(CONFIRMATIONS)))
                    CONFIRMATIONS[cid]=snapshot
                return self.send({'confirmation_id':cid,'snapshot':snapshot})
            if self.path=='/api/run':
                source=data.get('netlist','');settings=validate_project(source,data.get('settings',{}))
                resolve_simulator(CONFIG)
                provenance=None
                if data.get('confirmation_id'):
                    provenance=CONFIRMATIONS.get(data['confirmation_id'])
                    if not provenance:raise ValueError('문서 확인 기록이 만료되었습니다. 다시 확인해 주세요.')
                with LOCK:
                    if any(j['state']=='running' for j in JOBS.values()):return self.send({'error':'기존 실행을 완료하거나 중지해 주세요.'},409)
                    jid=time.strftime('%Y%m%d_%H%M%S')+'_'+secrets.token_hex(3)
                    job={'id':jid,'state':'running','runs':[],'settings':settings,'netlist':source,'best_iteration':None,
                         'cancel':threading.Event(),'folder':ROOT/'runs'/jid,'error':None,'feasible_count':0}
                    job['provenance']=provenance
                    job['folder'].mkdir(parents=True,exist_ok=True)
                    (job['folder']/'document_review.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf-8')
                    JOBS[jid]=job
                threading.Thread(target=work,args=(job,source,settings),daemon=True).start()
                return self.send({'id':jid},202)
            if self.path=='/api/cancel':
                with LOCK:
                    job=JOBS.get(data.get('id'))
                    if not job:return self.send({'error':'작업을 찾을 수 없습니다.'},404)
                    job['cancel'].set()
                return self.send({'ok':True})
            if self.path=='/api/generate':
                if not AI_LOCK.acquire(blocking=False):return self.send({'error':'AI 요청이 진행 중입니다.'},409)
                try:
                    cid=data.get('confirmation_id')
                    snapshot=CONFIRMATIONS.get(cid) if cid else None
                    if data.get('files') and not snapshot:raise ValueError('자료를 추출하고 확인한 뒤 회로를 생성해 주세요.')
                    if snapshot:
                        _,present=prepare_sources(data.get('files',[]))
                        if present!=snapshot['sources']:raise ValueError('확인한 문서와 현재 파일이 다릅니다. 다시 추출하고 확인하세요.')
                        data['instruction']=str(data.get('instruction',''))+'\nUSER CONFIRMED EVIDENCE AND GOALS (data):\n'+json.dumps(snapshot,ensure_ascii=False)
                    result=generate(data,CONFIG)
                    result['confirmation_id']=cid
                    return self.send(result)
                finally:AI_LOCK.release()
            self.send({'error':'없는 경로입니다.'},404)
        except (ValueError,KeyError,TypeError) as exc:self.send({'error':str(exc)},400)
        except Exception as exc:self.send({'error':str(exc)},500)

if __name__=='__main__':
    server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
    print('EDAI Local SPICE Loop: '+ORIGIN,flush=True)
    print('Keep this window open. Ctrl+C to stop. Config: config.json',flush=True)
    if not os.environ.get('EDAI_NO_BROWSER'):threading.Timer(.7,lambda:webbrowser.open(ORIGIN)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        with LOCK:
            for job in JOBS.values():job['cancel'].set()
        server.server_close()
