"""Local SPICE runner and bounded parameter optimization. No AI required."""
from __future__ import annotations
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

NUMBER=r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'
NAME=re.compile(r'^[A-Za-z][A-Za-z0-9_]{0,40}$')
ALLOWED_DOTS={'.param','.model','.subckt','.ends','.func','.options','.option','.temp',
              '.ic','.nodeset','.save','.tran','.ac','.dc','.op','.meas','.measure','.end'}

def finite(value):
    n=float(value)
    if not math.isfinite(n): raise ValueError('숫자는 유한한 값이어야 합니다.')
    return n

def validate_netlist(text):
    if not isinstance(text,str) or not text.strip() or len(text)>100_000:
        raise ValueError('넷리스트는 비어 있지 않은 10만 자 이하 텍스트여야 합니다.')
    if '\x00' in text: raise ValueError('널 문자는 사용할 수 없습니다.')
    lines=text.replace('\r','').splitlines()
    if len(lines)>2000: raise ValueError('최대 2,000줄까지 지원합니다.')
    if not lines[0].strip() or lines[0].lstrip().startswith('.'):
        raise ValueError('첫 줄에 회로 제목 또는 * 주석을 넣어 주세요.')
    analyses=0; measures=[]; has_end=False
    for line in lines[1:]:
        line=line.strip()
        if not line or line.startswith('*'): continue
        if any(c in line for c in ['`','$','\\']):
            raise ValueError('외부 명령·변수 치환·파일 경로를 포함한 넷리스트는 지원하지 않습니다.')
        token=line.split()[0].lower()
        if token.startswith('.'):
            if token not in ALLOWED_DOTS:
                raise ValueError(f'{token}은 지원하지 않습니다. 단일 파일에 소자 모델을 포함하고 .control/.include/.lib/.step을 제거해 주세요.')
            if token in {'.tran','.ac','.dc','.op'}: analyses+=1
            if token in {'.meas','.measure'}:
                parts=line.split()
                if len(parts)<4 or parts[1].lower() not in {'tran','ac','dc'} or not NAME.fullmatch(parts[2]):
                    raise ValueError('.meas 형식을 확인해 주세요.')
                measures.append(parts[2].lower())
            if token=='.end': has_end=True
        elif line[0]!='+' and line[0].upper() not in 'RCLVIDQMBEGFHXKSWT':
            raise ValueError('지원하지 않는 소자/명령: '+token)
        if re.search(r'\b(?:file|pwlfile|load|source|shell)\s*=',line,re.I):
            raise ValueError('외부 파일 참조는 현재 버전에서 지원하지 않습니다.')
    if analyses!=1: raise ValueError('한 번에 .tran/.ac/.dc/.op 중 한 해석만 넣어 주세요(복합 테스트벤치는 분리).')
    if not measures: raise ValueError('목표 판정을 위한 .meas 측정 명령이 필요합니다.')
    if len(measures)!=len(set(measures)): raise ValueError('.meas 이름은 중복할 수 없습니다.')
    if not has_end: raise ValueError('마지막에 .end가 필요합니다.')
    return measures

def validate_project(netlist,settings):
    measures=validate_netlist(netlist)
    s=json.loads(json.dumps(settings,allow_nan=False))
    params=s.get('parameters',[])
    if not 1<=len(params)<=6: raise ValueError('최적화 변수는 1~6개여야 합니다.')
    seen=set()
    for p in params:
        n=p.get('name','')
        if not NAME.fullmatch(n) or n.lower() in seen: raise ValueError('파라미터 이름 또는 중복을 확인해 주세요.')
        seen.add(n.lower())
        for k in ('min','max','initial','step'): p[k]=finite(p[k])
        if not p['min']<p['max'] or not p['min']<=p['initial']<=p['max'] or p['step']<=0:
            raise ValueError(n+': 최소/최대/초기/간격 범위를 확인해 주세요.')
        pattern=r'(?im)^\s*\.param\s+'+re.escape(n)+r'\s*=\s*([^\n;]+)'
        hits=re.findall(pattern,netlist)
        if len(hits)!=1 or re.search(r'\s\w+\s*=',hits[0]):
            raise ValueError(f'.param {n}=숫자 를 독립된 한 줄에 한 번 선언해 주세요.')
    goals=s.get('goals',[])
    if not 1<=len(goals)<=12: raise ValueError('목표 조건은 1~12개가 필요합니다.')
    for g in goals:
        g['measure']=str(g.get('measure','')).lower()
        if g['measure'] not in measures or g.get('op') not in ('>=','<='):
            raise ValueError('목표의 measure는 .meas 이름과 같아야 하며, op는 >= 또는 <= 입니다.')
        g['value']=finite(g['value'])
    obj=s.get('objective',{})
    obj['measure']=str(obj.get('measure','')).lower()
    if obj['measure'] not in measures or obj.get('sense') not in ('min','max'):
        raise ValueError('objective에 .meas 이름과 min/max를 지정해 주세요.')
    s['max_runs']=int(s.get('max_runs',32));s['timeout_s']=finite(s.get('timeout_s',20))
    if not 1<=s['max_runs']<=128 or not 1<=s['timeout_s']<=60:
        raise ValueError('실행 횟수는 1~128회, 회당 제한시간은 1~60초입니다.')
    if s.get('method') not in ('single','grid','feedback'): raise ValueError('method는 single, grid, feedback 중 하나입니다.')
    return s

def resolve_simulator(config):
    engine=config.get('simulator','ngspice').lower()
    if engine not in ('ngspice','ltspice'): raise ValueError('simulator는 ngspice 또는 ltspice 입니다.')
    explicit=str(config.get('simulator_path','')).strip()
    if explicit:
        path=Path(explicit).expanduser()
        if not path.is_file(): raise ValueError('config.json의 simulator_path 파일을 찾을 수 없습니다.')
        return engine,str(path.resolve())
    candidates=[]
    if engine=='ngspice':
        candidates=[shutil.which('ngspice'),shutil.which('ngspice_con'),r'C:\Spice64\bin\ngspice_con.exe',r'C:\Spice64\bin\ngspice.exe']
    else:
        candidates=[str(Path(os.environ.get('LOCALAPPDATA',''))/'Programs/ADI/LTspice/LTspice.exe'),r'C:\Program Files\ADI\LTspice\LTspice.exe',r'C:\Program Files\LTC\LTspiceXVII\XVIIx64.exe',shutil.which('LTspice')]
    for p in candidates:
        if p and Path(p).is_file(): return engine,str(Path(p).resolve())
    raise ValueError(engine+' 실행 파일을 찾지 못했습니다. config.json에 simulator_path를 지정해 주세요.')

def render_netlist(source,params):
    text=source
    for n,v in params.items():
        pat=r'(?im)^(\s*\.param\s+'+re.escape(n)+r'\s*=\s*)[^\n;]+'
        text,count=re.subn(pat,lambda m:m.group(1)+format(v,'.12g'),text)
        if count!=1: raise ValueError('파라미터 치환 실패: '+n)
    return text

def read_text(path):
    b=Path(path).read_bytes()
    if b.startswith((b'\xff\xfe',b'\xfe\xff')) or b[:200].count(b'\0')>20:
        return b.decode('utf-16',errors='replace')
    return b.decode('utf-8',errors='replace')

def parse_measurements(log,names):
    result={}
    for name in names:
        # ngspice: gain = 1.2e1; LTspice: gain: expression=1.2e1
        pattern=r'(?im)^\s*'+re.escape(name)+r'(?:\s*:[^\r\n=]*)?\s*=\s*('+NUMBER+r')(?=\s|$)'
        match=re.search(pattern,log)
        if match:
            v=float(match[1])
            if math.isfinite(v): result[name]=v
    return result

def parse_raw(path,limit=900):
    path=Path(path)
    if not path.exists() or path.stat().st_size>40_000_000:return None
    text=read_text(path)
    if 'Values:' not in text or re.search(r'Flags:.*complex',text):return None
    sections=text.split('Values:',1)
    if 'Variables:' not in sections[0]:return None
    variables=[]
    for line in sections[0].split('Variables:',1)[1].splitlines():
        m=re.match(r'\s*\d+\s+(\S+)\s+(\S+)',line)
        if m:variables.append(m.group(1))
    n=len(variables)
    if n<2 or n>200:return None
    data=[];point=[]
    for line in sections[1].splitlines():
        fields=line.split()
        if not fields:continue
        try:
            if len(point)==0:point=[float(fields[-1])]
            else:point.append(float(fields[-1]))
        except ValueError:continue
        if len(point)==n:
            if all(math.isfinite(x) for x in point):data.append(point)
            point=[]
    if not data:return None
    stride=max(1,math.ceil(len(data)/limit));sample=data[::stride]
    if sample[-1]!=data[-1]:sample.append(data[-1])
    return {'variables':variables,'points':sample,'total_points':len(data),'decimated':stride>1}

def run_spice(source,params,config,folder,timeout=20,cancel=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    names=validate_netlist(source)
    engine,exe=resolve_simulator(config)
    clean=render_netlist(source,params)
    (folder/'circuit.cir').write_text(clean,encoding='utf-8')
    actual=clean
    if engine=='ngspice':
        control='.control\nset filetype=ascii\nrun\nwrite waveform.raw all\nquit\n.endc\n.end'
        actual=re.sub(r'(?im)^\s*\.end\s*(?:;[^\n]*)?$',lambda m:control,clean)
        (folder/'execute.cir').write_text(actual,encoding='utf-8')
        cmd=[exe,'-n','-b','-o','simulation.log','execute.cir']
    else:cmd=[exe,'-b','-ascii',str((folder/'circuit.cir').resolve())]
    started=time.monotonic();failure=None
    with (folder/'console.log').open('wb') as out:
        proc=subprocess.Popen(cmd,cwd=folder,stdout=out,stderr=subprocess.STDOUT,shell=False,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0) if os.name=='nt' else 0)
        while proc.poll() is None:
            if cancel and cancel.is_set():failure='cancelled'
            elif time.monotonic()-started>timeout:failure='timeout'
            elif sum(p.stat().st_size for p in folder.iterdir() if p.is_file())>100_000_000:failure='output_limit'
            if failure:
                proc.terminate()
                try:proc.wait(timeout=2)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()
                break
            time.sleep(.04)
    log='\n'.join(read_text(p) for p in [folder/'simulation.log',folder/'circuit.log',folder/'console.log'] if p.exists())
    metrics=parse_measurements(log,names)
    if not failure and proc.returncode!=0:failure='simulator_error'
    raw=folder/('waveform.raw' if engine=='ngspice' else 'circuit.raw')
    waveform=parse_raw(raw)
    return {'engine':engine,'parameters':params,'metrics':metrics,'error':failure,
            'returncode':proc.returncode,'elapsed_s':round(time.monotonic()-started,3),
            'source_sha256':hashlib.sha256(clean.encode()).hexdigest(),
            'executed_sha256':hashlib.sha256(actual.encode()).hexdigest(),
            'log_tail':log[-14000:],'waveform':waveform,'directory':folder.name}

def assess(result,settings):
    checks=[];missing=[];violation=0.0
    for goal in settings['goals']:
        m=goal['measure'];actual=result['metrics'].get(m);target=goal['value']
        passed=actual is not None and (actual>=target if goal['op']=='>=' else actual<=target)
        if actual is None:missing.append(m)
        else:violation+=max(0,(target-actual) if goal['op']=='>=' else (actual-target))/max(abs(target),1e-9)
        checks.append({**goal,'actual':actual,'passed':passed})
    objective=result['metrics'].get(settings['objective']['measure'])
    if objective is None:missing.append(settings['objective']['measure'])
    valid=not result['error'] and not missing
    rank=(violation,objective if settings['objective']['sense']=='min' else -objective) if valid else (math.inf,math.inf)
    result.update({'checks':checks,'valid':valid,'feasible':valid and all(c['passed'] for c in checks),
                   'violation':violation if valid else None,'missing_measures':sorted(set(missing))})
    if not valid:result['feedback']='측정/실행 실패: '+(', '.join(sorted(set(missing))) or str(result['error']))+'. 실패한 후보는 최적 후보에서 제외했습니다.'
    elif result['feasible']:result['feedback']='설정한 목표를 모두 만족했습니다. 같은 조건에서 목적 지표가 더 좋은 후보를 계속 비교합니다.'
    else:result['feedback']=' · '.join(f"{c['measure']} {c['actual']:.5g} (목표 {c['op']} {c['value']:.5g})" for c in checks if not c['passed'])
    return rank

def grid_values(p):
    count=math.floor((p['max']-p['min'])/p['step']+1e-8)+1
    if count>2000:raise ValueError('그리드 간격이 너무 작습니다. feedback 방식을 사용해 주세요.')
    return sorted(set([round(p['min']+i*p['step'],12) for i in range(count)]+[p['initial'],p['max']]))

def optimize(source,settings,config,folder,on_result=lambda r,b:None,cancel=None):
    s=validate_project(source,settings);resolve_simulator(config)
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    (folder/'project.json').write_text(json.dumps({'netlist':source,'settings':s},ensure_ascii=False,indent=2),encoding='utf-8')
    specs=s['parameters'];start={p['name']:p['initial'] for p in specs};history=[];seen=set();best=None;best_rank=(math.inf,math.inf)
    def evaluate(params,reason):
        nonlocal best,best_rank
        key=tuple(round(params[p['name']],12) for p in specs)
        if key in seen or len(history)>=s['max_runs'] or (cancel and cancel.is_set()):return False
        seen.add(key);index=len(history)
        r=run_spice(source,dict(params),config,folder/f'run_{index:03d}',s['timeout_s'],cancel)
        r['iteration']=index;r['reason']=reason
        rank=assess(r,s);improved=rank<best_rank
        if improved:best_rank=rank;best=r
        r['new_best']=improved
        history.append(r)
        (folder/f'run_{index:03d}'/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
        on_result(r,best)
        return improved
    if s['method']=='grid':
        values=[grid_values(p) for p in specs]
        size=math.prod(len(v) for v in values)
        if size>s['max_runs']:raise ValueError(f'그리드 {size}개가 실행 한도 {s["max_runs"]}회를 넘습니다. 간격을 늘리거나 feedback으로 바꿔 주세요.')
        evaluate(start,'초기 설계')
        for vals in itertools.product(*values):evaluate(dict(zip(start,vals)),'전체 그리드의 후보 검증')
    else:
        evaluate(start,'초기 설계')
        steps={p['name']:p['step'] for p in specs}
        for cycle in range(24):
            if s['method']=='single' or len(history)>=s['max_runs'] or (cancel and cancel.is_set()):break
            center=dict(best['parameters'] if best else start);improved=False
            for p in specs:
                n=p['name']
                for sign in (1,-1):
                    trial=dict(center);trial[n]=round(min(p['max'],max(p['min'],center[n]+sign*steps[n])),12)
                    improved=evaluate(trial,f"이전 최선 후보 주변 {n}: {center[n]:.6g} → {trial[n]:.6g} 검증") or improved
            if not improved:
                steps={n:v/2 for n,v in steps.items()}
                if all(steps[p['name']]<p['step']/16 for p in specs):break
    summary={'schema_version':'edai-spice-loop-1.0','kind':'actual_spice_runs','settings':s,
             'engine':config['simulator'],'runs':history,'best_iteration':best['iteration'] if best else None,
             'feasible_count':sum(r['feasible'] for r in history),'cancelled':bool(cancel and cancel.is_set()),
             'scope':'Only submitted parameter ranges, targets and testbench; no global optimum, silicon or PVT guarantee.'}
    (folder/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    if best:shutil.copyfile(folder/best['directory']/'circuit.cir',folder/'best.cir')
    return summary
