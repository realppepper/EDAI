# EDAI Circuit Studio v03 팀 검토본

자료 입력 → OpenRouter 항목 추출 → 사용자 확인 → 회로 초안 생성 → 로컬 SPICE 실행 → 결과 비교를 연결하는 Python 기반 로컬 프로그램입니다.

## 현재 상태

- 사용자 Windows 화면에서 LTspice 26.1.1 실행과 실제 로그 표시를 확인했습니다.
- 요청 모델 ID: `google/gemini-3.1-flash-lite` (OpenRouter).
- 현재 OP-AMP 사례: 후보 1개, 전체 목표 충족 후보 0개. 최대 실행 횟수를 1로 설정했습니다.
- `.meas WHEN` 출력에서 교차 시점 대신 조건값을 읽는 오류가 있습니다. `docs/KNOWN_ISSUES.md`를 먼저 읽으세요.
- 교육용 행동 모델의 전원 소비·피드백 구조·측정 정의를 보완해야 합니다. 이 사례는 실제 CMOS 소자의 성능 검증 결과가 아닙니다.

## 설치와 실행

1. 이 폴더 전체를 예를 들어 `C:\EDAI\team03`에 압축 해제하세요. 기존 설치 폴더는 보관하고 별도 폴더에서 확인하세요.
2. Python 3.10 이상과 LTspice를 각자 설치하세요. LTspice 실행 파일·설치 프로그램은 배포물에 포함하지 않았습니다.
3. `INSTALL_PDF_SUPPORT.bat`을 실행하여 PDF 처리용 PyMuPDF를 설치하세요.
4. AI 없이 확인하려면 `START_WINDOWS.bat`을 실행하세요. 브라우저 주소는 `http://127.0.0.1:8765`입니다. 콘솔 창은 실행 중 유지하세요.
5. 연결 설정에서 LTspice를 선택하고 실행 경로를 확인하세요. 자동 탐색이 안 되면 설치된 실행 파일의 실제 경로를 입력하세요.
6. AI를 사용하려면 서버를 Ctrl+C로 종료한 후 `START_WITH_AI.bat`을 실행하세요. Model ID와 본인 OpenRouter API 키를 입력합니다. 키 입력은 화면에 표시되지 않습니다.
7. `py` 명령이 없으면 Python 설치를 확인하거나 `.venv\Scripts\python.exe start_with_ai.py`를 실행하세요. PDF 설치가 완료돼 있어야 가상환경 실행 파일이 있습니다.

## 자료 분석 과정 재현

샘플 문서: `web/studio/samples/EDAI_Demo_Datasheet.pdf`.
이 문서는 제조사 데이터시트가 아니라 교육용 합성 목표 문서입니다.

`문자 · 이미지 · PDF` 탭에서 아래 요청을 입력하고 PDF를 선택하세요.

```text
확인된 목표를 참고해 교육용 OP-AMP 회로 초안과 SPICE 테스트벤치를 작성해줘.
해석 명령은 .tran 하나만 사용하고 .ac, .dc, .op는 넣지 마.
제공되지 않은 소자 모델은 교육용 가정임을 명확히 표시해줘.
위상 여유와 대역폭은 이번 과도해석으로 검증했다고 주장하지 말고, 별도의 AC 테스트가 필요하다고 알려줘.
```

AI 항목 추출 → 값·단위·출처 대조 → 확인 체크 → 확인한 정보 저장 → 회로 초안 생성 순서입니다. 호출 결과는 매번 달라질 수 있으며, API 요금과 모델 접근권한은 본인 계정에 따라 달라집니다. AI 응답만으로 회로 성능이 검증되지는 않습니다.

오늘의 회로를 살펴보려면 `examples/observed_opamp_20261111.cir`를 여세요. 화면에서 전사한 진단용 사례이며 권장 설계가 아닙니다. 설정은 같은 이름의 JSON에 있습니다. 사용자 PC 원본 실행 파일과 동일하다고 인증하지 않습니다.

## 코드 구성

| 파일 | 역할 |
|---|---|
| server.py | 로컬 HTTP API, 확인 기록, 실행 작업, 결과 ZIP |
| review.py | PDF 텍스트·AI 항목 추출 및 출처 확인 |
| ai_input.py | OpenRouter 회로 생성 요청·JSON 진단·넷리스트 검증 |
| engine.py | SPICE 실행, 로그·raw 해석, 파라미터 탐색·목표 판정 |
| start_with_ai.py | 모델 입력과 프로세스 환경변수 API 키 설정 |
| web/app.js, web/review.js | 실행·자료 검토·결과 화면 |
| web/studio/ | 과거 수학 모델 데모. 현재 SPICE 결과와 별도 |
| validation/ | 이전 ngspice 공통 소스 예제 검증 기록 |
| tools/reproduce_when_issue.py | 현재 WHEN 로그 파싱 오류 재현 |

기존 validation의 32회 실행·13개 충족·#28은 과거 ngspice 공통 소스 회로 결과입니다. 오늘 LTspice OP-AMP 결과 1회·0개 충족·#00과 섞어 발표하지 마세요.

## 코드 검토 결과

2026-11-11 공유본 검토에서 기존 자동 테스트 9개 중 5개 통과, 실제 시뮬레이터가 필요한 4개는 실행하지 않았습니다. 실시간 API 재호출이나 Windows LTspice 재실행을 한 결과가 아닙니다.

```text
python -m unittest discover -s tests -v
python tools/reproduce_when_issue.py
```

이전 수정 파일의 출처는 `docs/source_assembly.json`, 알려진 문제와 다음 작업은 `docs/KNOWN_ISSUES.md`, 코드 검토 기록은 `docs/REVIEW_REPORT.md`에 있습니다. `SHA256SUMS.json`은 이번 배포본 파일의 해시입니다.

## 저장과 공유

설정은 config.json, 실행 기록은 runs/에 만들어집니다. API 키는 프로세스 환경변수로 전달하며 번들에 포함하지 않습니다. 사용자의 업로드 원문·개인 경로가 실행 기록에 들어갈 수 있으므로 결과 ZIP은 공유 전에 확인하세요. `.venv`, config.json, .env, 개인 runs/는 GitHub에 올리지 마세요.

기본 주소는 본인 PC에서만 접속하는 loopback입니다. 이 프로그램을 그대로 공개 서버에 배포하는 범위는 검토하지 않았습니다. 팀원은 각자의 PC에서 실행하세요.
